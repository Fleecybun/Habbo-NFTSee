# Habbo Watchtower v0.5

## Changes in this update

- Added an on-screen scan progress bar.
- Added progress text showing scanned items, total items for the current scan, and remaining items.
- Initial full scan now shows progress across the entire grouped wallet inventory.
- Regular/watch scans now show progress across the configured per-scan batch.
- Persistent watcher notification now includes a progress bar while scanning.
- Scan progress is saved to local preferences so the UI can refresh live while the foreground service is running.

## Still included from the previous update

- First scan checks every grouped wallet item and pulls sale history/floor data before normal capped scanning begins.
- User is warned that the initial scan can take a long time.
- Normal scan limit remains configurable after the initial scan, default 50 and max 100.
- Sort / scan priority controls both display order and which items are scanned first.
- Added fluidity sorting for 3 days, 2 weeks, and 1 month.
- Debug buy-alert button is visible in Settings.
- Duplicate wallet items are grouped with quantity.
- Wallet items show monthly average, median, floor, top bid, estimated value, mover score, and fluidity counts.
- Buy/sell suggestions are saved in on-device alert history.
- Still read-only: no wallet connection, no keys, no signing, no contract writes.

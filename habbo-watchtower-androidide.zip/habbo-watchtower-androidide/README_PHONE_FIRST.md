# Habbo Watchtower Native Android

A phone-first, read-only Android watcher for Habbo / Immutable zkEVM market signals.

Default wallet:

`0xb6811b65fe7d75eda6f840426206a1d22ae69c10`

## What this app does

- Runs as an Android foreground service so it can keep scanning while your phone is locked.
- Shows a persistent watcher notification while active.
- Groups duplicate wallet items into one row and shows the combined quantity.
- Shows cached wallet-item market data: monthly average, median, current floor, top bid, and sale count.
- Lets you choose display currency: ETH, USD, EUR, JPY, GBP, AUD, or CAD.
- Sends separate high-priority Android notifications for each buy/sell suggestion.
- Keeps in-app alert history in on-device SQLite so swiped-away notifications are not lost.
- Lets you toggle sell alerts per grouped wallet item.
- Has a Settings debug button that queues a fake buy alert for the next scan.
- Uses public HTTP APIs only.
- Does not connect a wallet.
- Does not request seed phrases.
- Does not store private keys.
- Does not sign transactions.
- Does not call smart contracts directly.

## Why foreground service?

Android limits normal background work. A foreground service is the practical way to keep a market watcher alive on-device. The tradeoff is a persistent notification while the watcher is running.

## Permissions

- INTERNET: read market/API data
- ACCESS_NETWORK_STATE: avoid unnecessary scans when offline
- POST_NOTIFICATIONS: show alerts on Android 13+
- FOREGROUND_SERVICE / FOREGROUND_SERVICE_DATA_SYNC: keep scanner running visibly
- RECEIVE_BOOT_COMPLETED: optionally resume watcher after phone restart if it was enabled
- WAKE_LOCK: help the active scan finish cleanly

## Build APK from your phone, no PC

The easiest no-PC route is GitHub Actions:

1. Create a new GitHub repository from your phone browser.
2. Upload the project zip or folder contents, depending on the workflow you are using.
3. Go to the repository's Actions tab.
4. Run the workflow named `Build debug APK` or your `Build APK from Zip` workflow.
5. Download the artifact named `habbo-watchtower-debug-apk`.
6. Open the APK on your phone and allow installing from your browser/files app.

That produces a debug APK. It is okay for personal testing, but not for Play Store distribution.

## First run

1. Open the app.
2. Allow notifications.
3. Tap Settings to choose currency, thresholds, and optional API key.
4. Tap Scan now to pull your wallet items.
5. Toggle sell alerts per item.
6. Tap Alert history to see saved buy/sell suggestions.
7. Tap Start watcher.
8. Leave the persistent watcher notification enabled.

## Suggested Android battery settings

Different phone makers are aggressive about killing background apps. If alerts stop, open the app's Android settings and set battery usage to unrestricted / not optimized.

The app includes a button called `Battery settings` to help get there.

## Current thresholds

- Cheap listing alert: listing/floor <= 70% of recent sale median
- Sell alert: top bid or floor >= 120% of recent sale median
- Minimum sales before alerting: 2
- Sales lookback: 30 days
- Scan interval: 10 minutes
- Display currency: USD by default

All of these can be changed in Settings.

## v0.2 notes

- Habbo says most Collectible trading is done using ETH, so the app displays ETH as the base price and converts it to fiat using CoinGecko.
- It scans the first 40 grouped wallet items per interval to avoid API bursts and battery drain.
- Duplicate grouping uses `metadata_id`/stack ID when available, then falls back to item name. If an item lacks usable metadata, it may still appear as an individual token.
- Current floor comes from Immutable pricing data for the representative token/stack where available.
- Sale average is based on recent sale activity for owned token IDs in that grouped item. A future version should use richer metadata-stack sales history when the best endpoint shape is confirmed.
- TokenTrove deep links are not wired yet, because marketplace URL formats should be verified against real listings.

## Best next upgrades

- Stack-aware sales history using Immutable metadata-stack endpoints.
- TokenTrove deep links for each alert.
- Alert confidence score: sale count + recency + spread + floor depth.
- Quiet hours.
- Per-item thresholds instead of global thresholds.
- Notification actions: mute item, open listing, scan now.
- CSV export for alert history.

## v0.3 scan controls

The watcher now has two controls for phone load:

- Items checked per scan: default 50, clamped between 1 and 100.
- Sort / scan priority: the same setting controls the wallet list order and which grouped wallet items are checked first when the scan limit is lower than the wallet size.

Sort options:

- Value: estimated holding value first, using floor, top bid, median, average, or last sale as fallback.
- Top movers: biggest percentage move away from the monthly median first.
- Discounts: current floor below monthly median first.
- Most liquid: highest monthly sales count first.
- Slow movers: lowest monthly sales count first.
- Unpriced first: items without cached market data first.
- Oldest checked: oldest cached market check first.
- A-Z: alphabetical.

Pricing inputs are still read-only. Inventory comes from Immutable account NFT data. Sale stats use sale activity history. Current floor/top-bid/listing signals use Immutable quote/order data.

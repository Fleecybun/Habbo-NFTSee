# Habbo Watchtower Native Android

A phone-first, read-only Android watcher for Habbo / Immutable zkEVM market signals.

Default wallet:

`0xb6811b65fe7d75eda6f840426206a1d22ae69c10`

## What this app does

- Runs as an Android foreground service so it can keep scanning while your phone is locked.
- Shows a persistent watcher notification while active.
- Sends high-priority Android notifications for:
  - active listings significantly below recent sale median
  - strong top bids or high floor signals for items in your wallet
- Lets you toggle sell alerts per wallet item.
- Uses Immutable public HTTP APIs only.
- Does not connect a wallet.
- Does not request seed phrases.
- Does not store private keys.
- Does not sign transactions.
- Does not call smart contracts directly.

## Why foreground service?

Android limits normal background work. A foreground service is the practical way to keep a market watcher alive on-device. The tradeoff is a persistent notification while the watcher is running.

## Permissions

- INTERNET: read Immutable API data
- ACCESS_NETWORK_STATE: avoid unnecessary scans when offline
- POST_NOTIFICATIONS: show alerts on Android 13+
- FOREGROUND_SERVICE / FOREGROUND_SERVICE_DATA_SYNC: keep scanner running visibly
- RECEIVE_BOOT_COMPLETED: optionally resume watcher after phone restart if it was enabled
- WAKE_LOCK: help the active scan finish cleanly

## Build APK from your phone, no PC

The easiest no-PC route is GitHub Actions:

1. Create a new GitHub repository from your phone browser.
2. Upload the contents of this folder.
3. Go to the repository's Actions tab.
4. Run the workflow named `Build debug APK`.
5. Download the artifact named `habbo-watchtower-debug-apk`.
6. Open the APK on your phone and allow installing from your browser/files app.

That produces a debug APK. It is okay for personal testing, but not for Play Store distribution.

## First run

1. Open the app.
2. Allow notifications.
3. Tap Settings if you want to change thresholds or add an Immutable API key.
4. Tap Scan now to pull your wallet items.
5. Toggle sell alerts per item.
6. Tap Start watcher.
7. Leave the persistent watcher notification enabled.

## Suggested Android battery settings

Different phone makers are aggressive about killing background apps. If alerts stop, open the app's Android settings and set battery usage to unrestricted / not optimized.

The app includes a button called `Open battery settings` to help get there.

## Current thresholds

- Cheap listing alert: listing <= 70% of recent sale median
- Sell alert: top bid or floor >= 120% of recent sale median
- Minimum sales before alerting: 2
- Sales lookback: 30 days
- Scan interval: 10 minutes

All of these can be changed in Settings.

## v0.1 limitations

- It scans the first 40 wallet items per interval to avoid API bursts and battery drain.
- It compares exact contract + token ID sale history first. For fungible/stacked Habbo items, stack-level pricing support should be improved next.
- TokenTrove deep links are not wired yet, because marketplace URL formats should be verified against real listings.
- It assumes NATIVE/IMX pricing unless a future version adds payment-token options.

## Best next upgrades

- Stack-aware matching using `metadata_id` / stack quote endpoints.
- A watched collection allowlist beyond owned items.
- TokenTrove deep links for each alert.
- Confidence score: sale count + recency + spread + floor depth.
- Quiet hours.
- Alert categories: buy, sell, whale sweep, floor gap, bid spike.
- Export alerts to CSV.
- Optional Discord/Telegram mirror later, if you ever decide to host a tiny relay.

package com.feltch.habbowatchtower;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

final class WatchDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "habbo_watchtower.db";
    private static final int DB_VERSION = 1;

    WatchDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS alert_history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "signal_id TEXT UNIQUE NOT NULL," +
                "type TEXT NOT NULL," +
                "item_name TEXT," +
                "title TEXT NOT NULL," +
                "body TEXT NOT NULL," +
                "severity INTEGER NOT NULL DEFAULT 1," +
                "price_native REAL NOT NULL DEFAULT 0," +
                "reference_native REAL NOT NULL DEFAULT 0," +
                "created_millis INTEGER NOT NULL," +
                "notified INTEGER NOT NULL DEFAULT 0" +
                ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_alert_history_created ON alert_history(created_millis DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    boolean recordSignal(Models.AlertSignal signal, boolean notified) {
        if (signal == null || signal.id == null || signal.id.trim().isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("signal_id", signal.id);
        cv.put("type", signal.type == null ? "general" : signal.type);
        cv.put("item_name", signal.itemName == null ? "" : signal.itemName);
        cv.put("title", signal.title == null ? "" : signal.title);
        cv.put("body", signal.body == null ? "" : signal.body);
        cv.put("severity", signal.severity);
        cv.put("price_native", signal.priceNative);
        cv.put("reference_native", signal.referenceNative);
        cv.put("created_millis", signal.createdMillis > 0 ? signal.createdMillis : System.currentTimeMillis());
        cv.put("notified", notified ? 1 : 0);
        long inserted = db.insertWithOnConflict("alert_history", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        if (inserted < 0 && notified) {
            ContentValues update = new ContentValues();
            update.put("notified", 1);
            db.update("alert_history", update, "signal_id=?", new String[]{signal.id});
        }
        return inserted >= 0;
    }

    List<Models.AlertSignal> recentSignals(int limit) {
        List<Models.AlertSignal> out = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("alert_history",
                new String[]{"signal_id", "type", "item_name", "title", "body", "severity", "price_native", "reference_native", "created_millis"},
                null, null, null, null, "created_millis DESC", String.valueOf(Math.max(1, limit)));
        try {
            while (c.moveToNext()) {
                Models.AlertSignal s = new Models.AlertSignal(
                        c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getInt(5), c.getDouble(6), c.getDouble(7));
                s.createdMillis = c.getLong(8);
                out.add(s);
            }
        } finally {
            c.close();
        }
        return out;
    }

    void clearHistory() {
        getWritableDatabase().delete("alert_history", null, null);
    }
}

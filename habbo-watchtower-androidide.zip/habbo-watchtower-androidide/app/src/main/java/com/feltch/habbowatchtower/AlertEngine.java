package com.feltch.habbowatchtower;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class AlertEngine {
    private final Store store;

    AlertEngine(Store store) {
        this.store = store;
    }

    List<Models.AlertSignal> evaluateItem(Models.NftItem item, Models.PriceStats stats, Models.PriceQuote quote, List<Models.Listing> listings) {
        List<Models.AlertSignal> out = new ArrayList<>();
        if (stats.salesCount < store.minSales() || stats.medianNative <= 0.0) return out;

        double cheapLimit = stats.medianNative * store.cheapDiscount();
        if (listings != null && !listings.isEmpty()) {
            Models.Listing cheapest = listings.get(0);
            if (cheapest.priceNative > 0.0 && cheapest.priceNative <= cheapLimit) {
                double off = 100.0 * (1.0 - cheapest.priceNative / stats.medianNative);
                out.add(new Models.AlertSignal(
                        "cheap:" + cheapest.id,
                        "Cheap Habbo listing spotted",
                        item.name + " listed at " + fmt(cheapest.priceNative) + " IMX, about " + fmt(off) + "% under median sale " + fmt(stats.medianNative) + " IMX.",
                        3
                ));
            }
        }

        if (quote.floorNative > 0.0 && quote.floorListingId != null && !quote.floorListingId.isEmpty() && quote.floorNative <= cheapLimit) {
            double off = 100.0 * (1.0 - quote.floorNative / stats.medianNative);
            out.add(new Models.AlertSignal(
                    "cheap-floor:" + item.key() + ":" + quote.floorListingId,
                    "Cheap floor detected",
                    item.name + " floor is " + fmt(quote.floorNative) + " IMX, about " + fmt(off) + "% under median sale.",
                    2
            ));
        }

        if (store.sellAlertsEnabled(item.key())) {
            double sellTarget = stats.medianNative * store.sellPremium();
            if (quote.topBidNative >= sellTarget && quote.topBidNative > 0.0) {
                double premium = 100.0 * (quote.topBidNative / stats.medianNative - 1.0);
                out.add(new Models.AlertSignal(
                        "sell-bid:" + item.key() + ":" + quote.topBidId,
                        "Strong sell bid for your item",
                        item.name + " has a top bid at " + fmt(quote.topBidNative) + " IMX, about " + fmt(premium) + "% over median sale.",
                        4
                ));
            }
            if (quote.floorNative >= sellTarget && quote.floorNative > 0.0) {
                double premium = 100.0 * (quote.floorNative / stats.medianNative - 1.0);
                out.add(new Models.AlertSignal(
                        "sell-floor:" + item.key() + ":" + quote.floorListingId,
                        "High floor for your item",
                        item.name + " floor is " + fmt(quote.floorNative) + " IMX, about " + fmt(premium) + "% over median sale. Consider listing.",
                        2
                ));
            }
        }
        return out;
    }

    boolean shouldNotify(Models.AlertSignal signal) {
        long last = store.lastAlertMillis(signal.id);
        long cooldown = 6L * 60L * 60L * 1000L;
        return System.currentTimeMillis() - last > cooldown;
    }

    void markNotified(Models.AlertSignal signal) {
        store.markAlerted(signal.id);
    }

    private static String fmt(double d) {
        if (Math.abs(d) >= 100) return String.format(Locale.US, "%.0f", d);
        if (Math.abs(d) >= 1) return String.format(Locale.US, "%.3f", d);
        return String.format(Locale.US, "%.5f", d);
    }
}

package com.feltch.habbowatchtower;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private Store store;
    private LinearLayout root;
    private TextView status;
    private TextView wallet;
    private LinearLayout itemsBox;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { refresh(); }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new Store(this);
        buildUi();
        askNotificationPermissionIfNeeded();
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        registerReceiverCompat();
        refresh();
    }

    @Override protected void onPause() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        super.onPause();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root);

        TextView title = text("Habbo Watchtower", 26, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);
        TextView subtitle = text("Read-only Android watcher for Habbo market signals. No wallet connection, no keys, no signing.", 14, false);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, dp(6), 0, dp(14));
        root.addView(subtitle);

        status = text("", 16, false);
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(status);

        wallet = text("", 13, false);
        wallet.setPadding(0, dp(10), 0, dp(10));
        root.addView(wallet);

        LinearLayout row1 = row();
        Button start = button("Start watcher");
        start.setOnClickListener(v -> startWatcher());
        Button stop = button("Stop");
        stop.setOnClickListener(v -> stopWatcher());
        row1.addView(start, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row1.addView(stop, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(row1);

        LinearLayout row2 = row();
        Button scan = button("Scan now");
        scan.setOnClickListener(v -> scanOnce());
        Button settings = button("Settings");
        settings.setOnClickListener(v -> showSettings());
        row2.addView(scan, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row2.addView(settings, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(row2);

        Button battery = button("Open battery settings");
        battery.setOnClickListener(v -> openBatterySettings());
        root.addView(battery);

        TextView section = text("Wallet items / sell alert toggles", 20, true);
        section.setPadding(0, dp(22), 0, dp(8));
        root.addView(section);
        itemsBox = new LinearLayout(this);
        itemsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(itemsBox);

        TextView note = text("Tip: Start the watcher, then leave the persistent status notification alone. Android is far less likely to kill a foreground service than a normal background task.", 13, false);
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void refresh() {
        if (status == null) return;
        status.setText(store.statusText());
        wallet.setText("Wallet: " + store.wallet() + "\nScan every " + store.scanIntervalMinutes() + " min • sales lookback " + store.salesLookbackDays() + " days");
        itemsBox.removeAllViews();
        List<Models.NftItem> items = store.loadItems();
        if (items.isEmpty()) {
            TextView empty = text("No wallet items cached yet. Tap Scan now, or Start watcher.", 15, false);
            empty.setPadding(0, dp(8), 0, dp(8));
            itemsBox.addView(empty);
            return;
        }
        for (Models.NftItem item : items) {
            itemsBox.addView(itemRow(item));
        }
    }

    private View itemRow(Models.NftItem item) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView name = text(item.name, 16, true);
        TextView meta = text(shortAddress(item.contractAddress) + " #" + item.tokenId + " • balance " + item.balance, 12, false);
        Switch sw = new Switch(this);
        sw.setText("Sell alerts");
        sw.setChecked(store.sellAlertsEnabled(item.key()));
        sw.setOnCheckedChangeListener((CompoundButton buttonView, boolean isChecked) -> store.setSellAlertsEnabled(item.key(), isChecked));
        box.addView(name);
        box.addView(meta);
        box.addView(sw);
        return box;
    }

    private void showSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(8), dp(8), dp(8));

        EditText walletInput = input(store.wallet(), "Wallet address");
        EditText keyInput = input(store.immutableApiKey(), "Immutable API key / publishable key if needed");
        EditText intervalInput = input(String.valueOf(store.scanIntervalMinutes()), "Scan interval minutes");
        EditText lookbackInput = input(String.valueOf(store.salesLookbackDays()), "Sales lookback days");
        EditText minSalesInput = input(String.valueOf(store.minSales()), "Minimum sales before alerting");
        EditText cheapInput = input(String.valueOf((int)Math.round(store.cheapDiscount() * 100)), "Cheap alert percent of median, e.g. 70");
        EditText sellInput = input(String.valueOf((int)Math.round(store.sellPremium() * 100)), "Sell alert percent of median, e.g. 120");

        form.addView(label("Wallet")); form.addView(walletInput);
        form.addView(label("Immutable API key (optional)")); form.addView(keyInput);
        form.addView(label("Scan interval minutes")); form.addView(intervalInput);
        form.addView(label("Sales lookback days")); form.addView(lookbackInput);
        form.addView(label("Minimum sales")); form.addView(minSalesInput);
        form.addView(label("Cheap threshold %")); form.addView(cheapInput);
        form.addView(label("Sell premium %")); form.addView(sellInput);

        new AlertDialog.Builder(this)
                .setTitle("Watcher settings")
                .setView(form)
                .setPositiveButton("Save", (d, which) -> {
                    store.setWallet(walletInput.getText().toString());
                    store.setImmutableApiKey(keyInput.getText().toString());
                    store.setScanIntervalMinutes(parseInt(intervalInput.getText().toString(), 10));
                    store.setSalesLookbackDays(parseInt(lookbackInput.getText().toString(), 30));
                    store.setMinSales(parseInt(minSalesInput.getText().toString(), 2));
                    store.setCheapDiscount(parseInt(cheapInput.getText().toString(), 70) / 100.0);
                    store.setSellPremium(parseInt(sellInput.getText().toString(), 120) / 100.0);
                    Toast.makeText(this, "Settings saved. Restart watcher for interval changes.", Toast.LENGTH_LONG).show();
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startWatcher() {
        Intent service = new Intent(this, WatchService.class).setAction(WatchService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        Toast.makeText(this, "Watcher starting", Toast.LENGTH_SHORT).show();
    }

    private void stopWatcher() {
        Intent service = new Intent(this, WatchService.class).setAction(WatchService.ACTION_STOP);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
    }

    private void scanOnce() {
        Intent service = new Intent(this, WatchService.class).setAction(WatchService.ACTION_SCAN_ONCE);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        Toast.makeText(this, "Scan requested", Toast.LENGTH_SHORT).show();
    }

    private void askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        }
    }

    private void openBatterySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void registerReceiverCompat() {
        IntentFilter filter = new IntentFilter(WatchService.ACTION_REFRESH_UI);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));
        return row;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, true);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private EditText input(String value, String hint) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint);
        e.setSingleLine(true);
        return e;
    }

    private int parseInt(String raw, int fallback) {
        try { return Integer.parseInt(raw.trim()); } catch (Exception e) { return fallback; }
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String shortAddress(String a) {
        if (a == null || a.length() < 12) return a == null ? "" : a;
        return a.substring(0, 6) + "…" + a.substring(a.length() - 4);
    }
}

package com.feltch.habbowatchtower;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private Store store;
    private WatchDatabase db;
    private LinearLayout root;
    private TextView status;
    private TextView wallet;
    private LinearLayout itemsBox;
    private ProgressBar scanProgressBar;
    private TextView scanProgressText;
    private CurrencyRates rates;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { refresh(); }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new Store(this);
        db = new WatchDatabase(this);
        rates = CurrencyRates.load(this);
        buildUi();
        askNotificationPermissionIfNeeded();
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        rates = CurrencyRates.load(this);
        registerReceiverCompat();
        refresh();
    }

    @Override protected void onPause() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        super.onPause();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root);

        TextView title = text("Habbo Watchtower", 26, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);
        TextView subtitle = text("Read-only Android watcher for Habbo market signals. No wallet connection, no keys, no signing.", 14, false);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, dp(6), 0, dp(14));
        root.addView(subtitle);

        status = text("", 16, false);
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(status);

        scanProgressText = text("", 13, false);
        scanProgressText.setPadding(dp(12), 0, dp(12), dp(4));
        root.addView(scanProgressText);
        scanProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        scanProgressBar.setMax(100);
        scanProgressBar.setProgress(0);
        scanProgressBar.setPadding(dp(12), 0, dp(12), dp(10));
        root.addView(scanProgressBar);

        wallet = text("", 13, false);
        wallet.setPadding(0, dp(10), 0, dp(10));
        root.addView(wallet);

        LinearLayout row1 = row();
        Button start = button("Start watcher");
        start.setOnClickListener(v -> startWatcher());
        Button stop = button("Stop");
        stop.setOnClickListener(v -> stopWatcher());
        row1.addView(start, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row1.addView(stop, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(row1);

        LinearLayout row2 = row();
        Button scan = button("Scan now");
        scan.setOnClickListener(v -> scanOnce());
        Button settings = button("Settings");
        settings.setOnClickListener(v -> showSettings());
        row2.addView(scan, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row2.addView(settings, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(row2);

        LinearLayout row3 = row();
        Button history = button("Alert history");
        history.setOnClickListener(v -> showHistory());
        Button battery = button("Battery settings");
        battery.setOnClickListener(v -> openBatterySettings());
        row3.addView(history, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row3.addView(battery, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(row3);

        TextView section = text("Wallet items / sell alert toggles", 20, true);
        section.setPadding(0, dp(22), 0, dp(8));
        root.addView(section);
        itemsBox = new LinearLayout(this);
        itemsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(itemsBox);

        TextView note = text("Tip: Start the watcher, then leave the persistent status notification alone. Android is far less likely to kill a foreground service than a normal background task.", 13, false);
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void refresh() {
        if (status == null) return;
        rates = CurrencyRates.load(this);
        String statusText = store.statusText();
        if (!store.initialFullScanComplete()) {
            statusText += "\n\nFirst run note: the initial scan prices every grouped wallet item and pulls sale history for sorting. It can take a long time — please be patient.";
        }
        status.setText(statusText);
        updateProgressBar();
        wallet.setText("Wallet: " + store.wallet() + "\nScan every " + store.scanIntervalMinutes() + " min • up to " + store.scanBatchSize() + " items after initial full scan • priority " + store.itemSortMode() + "\nLookback " + store.salesLookbackDays() + " days • display " + store.displayCurrency() + "\n" + rates.staleLabel());
        itemsBox.removeAllViews();
        List<Models.NftItem> items = MarketSort.sortedCopy(store.loadItems(), store.itemSortMode());
        if (items.isEmpty()) {
            TextView empty = text("No wallet items cached yet. Tap Scan now, or Start watcher.", 15, false);
            empty.setPadding(0, dp(8), 0, dp(8));
            itemsBox.addView(empty);
            return;
        }
        for (Models.NftItem item : items) itemsBox.addView(itemRow(item));
    }

    private View itemRow(Models.NftItem item) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView name = text(item.name + (item.quantity > 1 ? " ×" + item.quantity : ""), 16, true);
        TextView meta = text(shortAddress(item.contractAddress) + " #" + item.tokenId + " • qty " + item.quantity, 12, false);
        TextView prices = text(priceLine(item), 13, false);
        prices.setPadding(0, dp(4), 0, dp(4));

        Switch sw = new Switch(this);
        sw.setText("Sell alerts");
        sw.setChecked(store.sellAlertsEnabled(item.key()));
        sw.setOnCheckedChangeListener((CompoundButton buttonView, boolean isChecked) -> store.setSellAlertsEnabled(item.key(), isChecked));

        box.addView(name);
        box.addView(meta);
        box.addView(prices);
        box.addView(sw);
        return box;
    }

    private String priceLine(Models.NftItem item) {
        String currency = store.displayCurrency();
        String avg = rates.format(item.monthlyAverageNative, currency);
        String median = rates.format(item.monthlyMedianNative, currency);
        String floor = rates.format(item.currentFloorNative, currency);
        String bid = rates.format(item.topBidNative, currency);
        String sales = item.monthlySalesCount <= 0 ? "no sales cached" : item.monthlySalesCount + " sales in 30d";
        String fluidity = "Fluidity: 3d " + item.salesCount3d + " • 2w " + item.salesCount14d + " • 1m " + item.salesCount30d;
        String updated = item.marketUpdatedMillis <= 0 ? "not priced yet" : "priced " + shortTime(item.marketUpdatedMillis);
        String value = rates.format(MarketSort.estimatedValue(item), currency);
        String move = percent(MarketSort.moveScore(item));
        return "Avg: " + avg + " • Median: " + median + "\nFloor: " + floor + " • Top bid: " + bid + "\nValue: " + value + " • Move: " + move + "\n" + sales + " • " + fluidity + "\n" + updated;
    }


    private void updateProgressBar() {
        if (scanProgressBar == null || scanProgressText == null) return;
        int done = store.scanProgressDone();
        int total = store.scanProgressTotal();
        String message = store.scanProgressMessage();
        boolean active = store.scanProgressActive();
        if (total <= 0 && (message == null || message.trim().isEmpty())) {
            scanProgressBar.setVisibility(View.GONE);
            scanProgressText.setVisibility(View.GONE);
            return;
        }
        scanProgressBar.setVisibility(View.VISIBLE);
        scanProgressText.setVisibility(View.VISIBLE);
        if (total > 0) {
            scanProgressBar.setIndeterminate(false);
            scanProgressBar.setMax(total);
            scanProgressBar.setProgress(Math.max(0, Math.min(done, total)));
            int remaining = Math.max(0, total - done);
            String prefix = active ? "Scanning" : "Last scan";
            String extra = (message == null || message.trim().isEmpty()) ? "" : "\n" + message;
            scanProgressText.setText(prefix + ": " + Math.max(0, Math.min(done, total)) + "/" + total + " items • " + remaining + " remaining" + extra);
        } else {
            scanProgressBar.setIndeterminate(true);
            scanProgressText.setText(message == null || message.trim().isEmpty() ? "Preparing scan…" : message);
        }
    }

    private void showSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(8), dp(8), dp(8));

        EditText walletInput = input(store.wallet(), "Wallet address");
        EditText keyInput = input(store.immutableApiKey(), "Immutable API key / publishable key if needed");
        EditText intervalInput = input(String.valueOf(store.scanIntervalMinutes()), "Scan interval minutes");
        EditText batchInput = input(String.valueOf(store.scanBatchSize()), "Wallet items checked per scan, 1-100");
        EditText lookbackInput = input(String.valueOf(store.salesLookbackDays()), "Sales lookback days");
        EditText minSalesInput = input(String.valueOf(store.minSales()), "Minimum sales before alerting");
        EditText cheapInput = input(String.valueOf((int)Math.round(store.cheapDiscount() * 100)), "Cheap alert percent of median, e.g. 70");
        EditText sellInput = input(String.valueOf((int)Math.round(store.sellPremium() * 100)), "Sell alert percent of median, e.g. 120");

        Spinner currencySpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Models.DISPLAY_CURRENCIES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        currencySpinner.setAdapter(adapter);
        int selected = 0;
        for (int i = 0; i < Models.DISPLAY_CURRENCIES.length; i++) if (Models.DISPLAY_CURRENCIES[i].equals(store.displayCurrency())) selected = i;
        currencySpinner.setSelection(selected);

        Spinner sortSpinner = new Spinner(this);
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Models.ITEM_SORT_OPTIONS);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(sortAdapter);
        int sortSelected = 0;
        for (int i = 0; i < Models.ITEM_SORT_OPTIONS.length; i++) if (Models.ITEM_SORT_OPTIONS[i].equals(store.itemSortMode())) sortSelected = i;
        sortSpinner.setSelection(sortSelected);

        Button debugButton = button(store.debugBuyNextScan() ? "Debug buy alert queued" : "Queue debug buy alert next scan");
        debugButton.setOnClickListener(v -> {
            store.setDebugBuyNextScan(true);
            debugButton.setText("Debug buy alert queued");
            Toast.makeText(this, "Debug buy alert will fire on the next scan.", Toast.LENGTH_LONG).show();
        });

        form.addView(label("Wallet")); form.addView(walletInput);
        form.addView(label("Display currency")); form.addView(currencySpinner);
        form.addView(label("Sort / scan priority")); form.addView(sortSpinner);
        form.addView(text("This controls the wallet list order and which items are checked first after the initial full-wallet pricing scan. Fluidity options sort by sale count in that window.", 12, false));
        form.addView(label("Debug")); form.addView(debugButton);
        form.addView(label("Immutable API key (optional)")); form.addView(keyInput);
        form.addView(label("Scan interval minutes")); form.addView(intervalInput);
        form.addView(label("Items checked per scan")); form.addView(batchInput);
        form.addView(label("Sales lookback days")); form.addView(lookbackInput);
        form.addView(label("Minimum sales")); form.addView(minSalesInput);
        form.addView(label("Cheap threshold %")); form.addView(cheapInput);
        form.addView(label("Sell premium %")); form.addView(sellInput);

        ScrollView settingsScroll = new ScrollView(this);
        settingsScroll.addView(form);

        new AlertDialog.Builder(this)
                .setTitle("Watcher settings")
                .setView(settingsScroll)
                .setPositiveButton("Save", (d, which) -> {
                    store.setWallet(walletInput.getText().toString());
                    store.setDisplayCurrency(String.valueOf(currencySpinner.getSelectedItem()));
                    store.setItemSortMode(String.valueOf(sortSpinner.getSelectedItem()));
                    store.setImmutableApiKey(keyInput.getText().toString());
                    store.setScanIntervalMinutes(parseInt(intervalInput.getText().toString(), 10));
                    store.setScanBatchSize(parseInt(batchInput.getText().toString(), 50));
                    store.setSalesLookbackDays(parseInt(lookbackInput.getText().toString(), 30));
                    store.setMinSales(parseInt(minSalesInput.getText().toString(), 2));
                    store.setCheapDiscount(parseInt(cheapInput.getText().toString(), 70) / 100.0);
                    store.setSellPremium(parseInt(sellInput.getText().toString(), 120) / 100.0);
                    Toast.makeText(this, "Settings saved. Restart watcher for interval changes.", Toast.LENGTH_LONG).show();
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showHistory() {
        List<Models.AlertSignal> signals = db.recentSignals(80);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        if (signals.isEmpty()) {
            box.addView(text("No buy/sell suggestions saved yet.", 15, false));
        } else {
            for (Models.AlertSignal s : signals) {
                TextView t = text(historyText(s), 14, false);
                t.setPadding(0, dp(6), 0, dp(10));
                box.addView(t);
            }
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("Alert history")
                .setView(scroll)
                .setPositiveButton("Close", null)
                .setNegativeButton("Clear", (d, which) -> {
                    db.clearHistory();
                    Toast.makeText(this, "Alert history cleared", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private String historyText(Models.AlertSignal s) {
        String currency = store.displayCurrency();
        String price = rates.format(s.priceNative, currency);
        String ref = rates.format(s.referenceNative, currency);
        return "[" + s.type.toUpperCase(Locale.US) + "] " + s.title + "\n" + shortTime(s.createdMillis) + " • " + s.itemName + "\n" + s.body + "\nPrice: " + price + " • Ref: " + ref;
    }

    private void startWatcher() {
        if (!store.initialFullScanComplete()) {
            confirmInitialFullScanThen(() -> startWatcherNow());
            return;
        }
        startWatcherNow();
    }

    private void startWatcherNow() {
        Intent service = new Intent(this, WatchService.class).setAction(WatchService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        Toast.makeText(this, store.initialFullScanComplete() ? "Watcher starting" : "Initial full scan starting — this can take a while", Toast.LENGTH_LONG).show();
    }

    private void stopWatcher() {
        Intent service = new Intent(this, WatchService.class).setAction(WatchService.ACTION_STOP);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
    }

    private void scanOnce() {
        if (!store.initialFullScanComplete()) {
            confirmInitialFullScanThen(() -> scanOnceNow());
            return;
        }
        scanOnceNow();
    }

    private void scanOnceNow() {
        Intent service = new Intent(this, WatchService.class).setAction(WatchService.ACTION_SCAN_ONCE);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        Toast.makeText(this, store.initialFullScanComplete() ? "Scan requested" : "Initial full scan requested — this can take a while", Toast.LENGTH_LONG).show();
    }

    private void confirmInitialFullScanThen(Runnable action) {
        new AlertDialog.Builder(this)
                .setTitle("Initial full scan")
                .setMessage("The first scan will check every grouped item in your wallet and pull sale history/floor data for sorting. With a large wallet, this can take a long time. Keep the watcher notification running and be patient.")
                .setPositiveButton("Start scan", (d, which) -> action.run())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        }
    }

    private void openBatterySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void registerReceiverCompat() {
        IntentFilter filter = new IntentFilter(WatchService.ACTION_REFRESH_UI);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));
        return row;
    }

    private Button button(String s) { Button b = new Button(this); b.setText(s); return b; }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, true);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private EditText input(String value, String hint) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint);
        e.setSingleLine(true);
        return e;
    }

    private int parseInt(String raw, int fallback) {
        try { return Integer.parseInt(raw.trim()); } catch (Exception e) { return fallback; }
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private static String shortAddress(String a) {
        if (a == null || a.length() < 12) return a == null ? "" : a;
        return a.substring(0, 6) + "…" + a.substring(a.length() - 4);
    }

    private static String shortTime(long millis) {
        try { return new SimpleDateFormat("MMM d HH:mm", Locale.US).format(new Date(millis)); }
        catch (Exception ignored) { return ""; }
    }

    private static String percent(double ratio) {
        if (Math.abs(ratio) < 0.000001) return "0%";
        return String.format(Locale.US, "%+.1f%%", ratio * 100.0);
    }
}

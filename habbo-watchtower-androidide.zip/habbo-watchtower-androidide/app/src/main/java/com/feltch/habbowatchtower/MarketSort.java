package com.feltch.habbowatchtower;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

final class MarketSort {
    private MarketSort() { }

    static List<Models.NftItem> sortedCopy(List<Models.NftItem> input, String mode) {
        List<Models.NftItem> items = new ArrayList<>(input);
        final String sort = normalize(mode);
        Collections.sort(items, comparator(sort));
        return items;
    }

    static String normalize(String mode) {
        if (mode == null) return Models.SORT_VALUE;
        for (String allowed : Models.ITEM_SORT_OPTIONS) {
            if (allowed.equalsIgnoreCase(mode.trim())) return allowed;
        }
        return Models.SORT_VALUE;
    }

    private static Comparator<Models.NftItem> comparator(String sort) {
        if (Models.SORT_OLDEST.equals(sort)) {
            return (a, b) -> compareOldest(a, b);
        }
        if (Models.SORT_TOP_MOVERS.equals(sort)) {
            return (a, b) -> Double.compare(Math.abs(moveScore(b)), Math.abs(moveScore(a)));
        }
        if (Models.SORT_DISCOUNTS.equals(sort)) {
            return (a, b) -> Double.compare(discountScore(b), discountScore(a));
        }
        if (Models.SORT_MOST_LIQUID.equals(sort)) {
            return fluidityComparator(30);
        }
        if (Models.SORT_FLUIDITY_3D.equals(sort)) {
            return fluidityComparator(3);
        }
        if (Models.SORT_FLUIDITY_14D.equals(sort)) {
            return fluidityComparator(14);
        }
        if (Models.SORT_FLUIDITY_30D.equals(sort)) {
            return fluidityComparator(30);
        }
        if (Models.SORT_SLOW_MOVERS.equals(sort)) {
            return (a, b) -> {
                int c = Integer.compare(a.monthlySalesCount, b.monthlySalesCount);
                if (c != 0) return c;
                return compareOldest(a, b);
            };
        }
        if (Models.SORT_UNPRICED.equals(sort)) {
            return (a, b) -> {
                boolean au = a.marketUpdatedMillis <= 0L;
                boolean bu = b.marketUpdatedMillis <= 0L;
                if (au != bu) return au ? -1 : 1;
                return compareOldest(a, b);
            };
        }
        if (Models.SORT_NAME.equals(sort)) {
            return (a, b) -> safeName(a).compareTo(safeName(b));
        }
        // Default: value first.
        return (a, b) -> compareValueDesc(a, b);
    }

    private static Comparator<Models.NftItem> fluidityComparator(final int days) {
        return (a, b) -> {
            int c = Integer.compare(fluidityCount(b, days), fluidityCount(a, days));
            if (c != 0) return c;
            return compareValueDesc(a, b);
        };
    }

    static int fluidityCount(Models.NftItem item, int days) {
        if (item == null) return 0;
        if (days <= 3) return item.salesCount3d;
        if (days <= 14) return item.salesCount14d;
        return item.salesCount30d > 0 ? item.salesCount30d : item.monthlySalesCount;
    }

    private static int compareValueDesc(Models.NftItem a, Models.NftItem b) {
        int c = Double.compare(estimatedValue(b), estimatedValue(a));
        if (c != 0) return c;
        c = Integer.compare(b.quantity, a.quantity);
        if (c != 0) return c;
        return safeName(a).compareTo(safeName(b));
    }

    private static int compareOldest(Models.NftItem a, Models.NftItem b) {
        long av = a.marketUpdatedMillis <= 0L ? Long.MIN_VALUE : a.marketUpdatedMillis;
        long bv = b.marketUpdatedMillis <= 0L ? Long.MIN_VALUE : b.marketUpdatedMillis;
        int c = Long.compare(av, bv);
        if (c != 0) return c;
        return safeName(a).compareTo(safeName(b));
    }

    static double estimatedUnitPrice(Models.NftItem item) {
        if (item == null) return 0.0;
        if (item.currentFloorNative > 0.0) return item.currentFloorNative;
        if (item.topBidNative > 0.0) return item.topBidNative;
        if (item.monthlyMedianNative > 0.0) return item.monthlyMedianNative;
        if (item.monthlyAverageNative > 0.0) return item.monthlyAverageNative;
        if (item.lastSaleNative > 0.0) return item.lastSaleNative;
        return 0.0;
    }

    static double estimatedValue(Models.NftItem item) {
        return estimatedUnitPrice(item) * Math.max(1, item == null ? 1 : item.quantity);
    }

    static double moveScore(Models.NftItem item) {
        if (item == null || item.monthlyMedianNative <= 0.0) return 0.0;
        double now = item.currentFloorNative > 0.0 ? item.currentFloorNative : item.lastSaleNative;
        if (now <= 0.0) return 0.0;
        return (now / item.monthlyMedianNative) - 1.0;
    }

    static double discountScore(Models.NftItem item) {
        double move = moveScore(item);
        return move < 0.0 ? Math.abs(move) : 0.0;
    }

    private static String safeName(Models.NftItem item) {
        String n = item == null || item.name == null ? "" : item.name;
        return n.toLowerCase(Locale.US);
    }
}

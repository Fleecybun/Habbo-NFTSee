package com.feltch.habbowatchtower;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

final class CurrencyRates {
    private static final String PREFS = "habbo_watchtower_rates";
    private static final long MAX_AGE_MS = 6L * 60L * 60L * 1000L;
    private final Map<String, Double> ethRates = new HashMap<>();
    private long updatedMillis = 0L;

    static CurrencyRates load(Context context) {
        CurrencyRates rates = new CurrencyRates();
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            rates.updatedMillis = prefs.getLong("updated_millis", 0L);
            JSONObject json = new JSONObject(prefs.getString("rates_json", "{}"));
            rates.ethRates.put("ETH", 1.0);
            for (String currency : Models.DISPLAY_CURRENCIES) {
                String k = currency.toLowerCase(Locale.US);
                double v = json.optDouble(k, 0.0);
                if (v > 0.0) rates.ethRates.put(currency, v);
            }
        } catch (Exception ignored) { }
        return rates;
    }

    static CurrencyRates refreshIfStale(Context context) {
        CurrencyRates existing = load(context);
        if (System.currentTimeMillis() - existing.updatedMillis < MAX_AGE_MS && !existing.ethRates.isEmpty()) return existing;
        try { return refresh(context); }
        catch (Exception ignored) { return existing; }
    }

    static CurrencyRates refresh(Context context) throws Exception {
        String currencies = "usd,eur,jpy,gbp,aud,cad";
        String url = "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=" + currencies;
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(12000);
        con.setReadTimeout(15000);
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", "HabboWatchtowerNative/0.2");
        int code = con.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code < 200 || code >= 300) throw new Exception("CoinGecko HTTP " + code + ": " + sb);

        JSONObject eth = new JSONObject(sb.toString()).optJSONObject("ethereum");
        if (eth == null) throw new Exception("CoinGecko response did not include ethereum.");
        JSONObject save = new JSONObject();
        CurrencyRates rates = new CurrencyRates();
        rates.ethRates.put("ETH", 1.0);
        save.put("eth", 1.0);
        for (String currency : Models.DISPLAY_CURRENCIES) {
            if ("ETH".equals(currency)) continue;
            String k = currency.toLowerCase(Locale.US);
            double v = eth.optDouble(k, 0.0);
            if (v > 0.0) {
                rates.ethRates.put(currency, v);
                save.put(k, v);
            }
        }
        rates.updatedMillis = System.currentTimeMillis();
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong("updated_millis", rates.updatedMillis)
                .putString("rates_json", save.toString())
                .apply();
        return rates;
    }

    String format(double ethAmount, String currency) {
        if (ethAmount <= 0.0) return "—";
        String c = normalize(currency);
        Double rate = ethRates.get(c);
        if (rate == null || rate <= 0.0) return trimEth(ethAmount) + " ETH";
        double converted = ethAmount * rate;
        if ("ETH".equals(c)) return trimEth(converted) + " ETH";
        if ("JPY".equals(c)) return "¥" + String.format(Locale.US, "%,.0f", converted);
        if ("USD".equals(c)) return "$" + money(converted);
        if ("EUR".equals(c)) return "€" + money(converted);
        if ("GBP".equals(c)) return "£" + money(converted);
        if ("AUD".equals(c)) return "A$" + money(converted);
        if ("CAD".equals(c)) return "C$" + money(converted);
        return money(converted) + " " + c;
    }

    String staleLabel() {
        if (updatedMillis <= 0L || ethRates.isEmpty()) return "Currency rates not cached yet";
        long mins = Math.max(0, (System.currentTimeMillis() - updatedMillis) / 60000L);
        if (mins < 60) return "Rates updated " + mins + " min ago";
        return "Rates updated " + (mins / 60) + " hr ago";
    }

    private static String normalize(String raw) {
        String c = raw == null ? "USD" : raw.trim().toUpperCase(Locale.US);
        for (String allowed : Models.DISPLAY_CURRENCIES) if (allowed.equals(c)) return c;
        return "USD";
    }

    private static String money(double v) {
        if (Math.abs(v) >= 1000) return String.format(Locale.US, "%,.0f", v);
        if (Math.abs(v) >= 1) return String.format(Locale.US, "%,.2f", v);
        return String.format(Locale.US, "%.4f", v);
    }

    private static String trimEth(double d) {
        if (Math.abs(d) >= 1) return String.format(Locale.US, "%.4f", d);
        if (Math.abs(d) >= 0.01) return String.format(Locale.US, "%.5f", d);
        return String.format(Locale.US, "%.7f", d);
    }
}

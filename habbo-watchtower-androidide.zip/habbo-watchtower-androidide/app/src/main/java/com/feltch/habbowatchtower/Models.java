package com.feltch.habbowatchtower;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class Models {
    static final String DEFAULT_WALLET = "0xb6811b65fe7d75eda6f840426206a1d22ae69c10";
    static final String CHAIN_NAME = "imtbl-zkevm-mainnet";
    static final String API_BASE = "https://api.immutable.com/v1/chains/" + CHAIN_NAME;

    // User-facing display options. Habbo Collectibles commonly trade in ETH;
    // these currencies are conversion targets for showing the same price in-app.
    static final String[] DISPLAY_CURRENCIES = new String[]{"ETH", "USD", "EUR", "JPY", "GBP", "AUD", "CAD"};

    static final String SORT_VALUE = "Value";
    static final String SORT_TOP_MOVERS = "Top movers";
    static final String SORT_DISCOUNTS = "Discounts";
    static final String SORT_MOST_LIQUID = "Most liquid";
    static final String SORT_SLOW_MOVERS = "Slow movers";
    static final String SORT_UNPRICED = "Unpriced first";
    static final String SORT_OLDEST = "Oldest checked";
    static final String SORT_NAME = "A-Z";
    static final String[] ITEM_SORT_OPTIONS = new String[]{
            SORT_VALUE,
            SORT_TOP_MOVERS,
            SORT_DISCOUNTS,
            SORT_MOST_LIQUID,
            SORT_SLOW_MOVERS,
            SORT_UNPRICED,
            SORT_OLDEST,
            SORT_NAME
    };

    static class NftItem {
        String contractAddress = "";
        String tokenId = "";          // representative token id for grouped rows
        String tokenIdsCsv = "";      // all owned token IDs folded into this row, comma-separated
        String name = "Unknown item";
        String image = "";
        String metadataId = "";
        String stackId = "";
        String balance = "1";
        int quantity = 1;

        // Cached market snapshot from the last scan. Values are stored in ETH-sized units before display conversion.
        int monthlySalesCount = 0;
        double monthlyAverageNative = 0.0;
        double monthlyMedianNative = 0.0;
        double currentFloorNative = 0.0;
        double topBidNative = 0.0;
        double lastSaleNative = 0.0;
        long marketUpdatedMillis = 0L;

        String key() {
            if (contractAddress == null) return "";
            String c = contractAddress.toLowerCase(Locale.US);
            if (metadataId != null && !metadataId.trim().isEmpty()) return c + ":metadata:" + metadataId.toLowerCase(Locale.US);
            if (stackId != null && !stackId.trim().isEmpty()) return c + ":stack:" + stackId.toLowerCase(Locale.US);
            if (name != null && !name.trim().isEmpty() && !"Unknown item".equalsIgnoreCase(name.trim())) {
                return c + ":name:" + name.trim().toLowerCase(Locale.US);
            }
            return c + ":token:" + (tokenId == null ? "" : tokenId.toLowerCase(Locale.US));
        }

        List<String> tokenIds() {
            List<String> ids = new ArrayList<>();
            String csv = tokenIdsCsv == null || tokenIdsCsv.trim().isEmpty() ? tokenId : tokenIdsCsv;
            if (csv == null) return ids;
            String[] parts = csv.split(",");
            for (String p : parts) {
                String v = p.trim();
                if (!v.isEmpty() && !ids.contains(v)) ids.add(v);
            }
            return ids;
        }
    }

    static class Listing {
        String id = "";
        String contractAddress = "";
        String tokenId = "";
        String metadataId = "";
        String seller = "";
        double priceNative = 0.0;
        double priceUsd = 0.0;
        String symbol = "ETH";
    }

    static class PriceStats {
        int salesCount = 0;
        double medianNative = 0.0;
        double averageNative = 0.0;
        double lastSaleNative = 0.0;
        long newestSaleMillis = 0L;
        final List<Double> samples = new ArrayList<>();

        void absorb(PriceStats other) {
            if (other == null) return;
            samples.addAll(other.samples);
            if (other.newestSaleMillis > newestSaleMillis) {
                newestSaleMillis = other.newestSaleMillis;
                lastSaleNative = other.lastSaleNative;
            }
            recompute();
        }

        void recompute() {
            java.util.Collections.sort(samples);
            salesCount = samples.size();
            if (salesCount <= 0) {
                medianNative = 0.0;
                averageNative = 0.0;
                return;
            }
            double sum = 0.0;
            for (double p : samples) sum += p;
            averageNative = sum / salesCount;
            int mid = salesCount / 2;
            if (salesCount % 2 == 0) medianNative = (samples.get(mid - 1) + samples.get(mid)) / 2.0;
            else medianNative = samples.get(mid);
        }
    }

    static class PriceQuote {
        double floorNative = 0.0;
        double floorUsd = 0.0;
        String floorListingId = "";
        double topBidNative = 0.0;
        double topBidUsd = 0.0;
        String topBidId = "";
        double lastTradeNative = 0.0;
        double lastTradeUsd = 0.0;
    }

    static class AlertSignal {
        String id;
        String type;
        String itemName;
        String title;
        String body;
        int severity;
        double priceNative;
        double referenceNative;
        long createdMillis;

        AlertSignal(String id, String type, String itemName, String title, String body, int severity, double priceNative, double referenceNative) {
            this.id = id;
            this.type = type;
            this.itemName = itemName;
            this.title = title;
            this.body = body;
            this.severity = severity;
            this.priceNative = priceNative;
            this.referenceNative = referenceNative;
            this.createdMillis = System.currentTimeMillis();
        }

        AlertSignal(String id, String title, String body, int severity) {
            this(id, "general", "", title, body, severity, 0.0, 0.0);
        }
    }
}

package com.feltch.habbowatchtower;

import java.util.ArrayList;
import java.util.List;

final class Models {
    static final String DEFAULT_WALLET = "0xb6811b65fe7d75eda6f840426206a1d22ae69c10";
    static final String CHAIN_NAME = "imtbl-zkevm-mainnet";
    static final String API_BASE = "https://api.immutable.com/v1/chains/" + CHAIN_NAME;

    static class NftItem {
        String contractAddress = "";
        String tokenId = "";
        String name = "Unknown item";
        String image = "";
        String metadataId = "";
        String balance = "1";

        String key() {
            return (contractAddress + ":" + tokenId).toLowerCase();
        }
    }

    static class Listing {
        String id = "";
        String contractAddress = "";
        String tokenId = "";
        String seller = "";
        double priceNative = 0.0;
        double priceUsd = 0.0;
        String symbol = "IMX";
    }

    static class PriceStats {
        int salesCount = 0;
        double medianNative = 0.0;
        double averageNative = 0.0;
        double lastSaleNative = 0.0;
        long newestSaleMillis = 0L;
        final List<Double> samples = new ArrayList<>();
    }

    static class PriceQuote {
        double floorNative = 0.0;
        double floorUsd = 0.0;
        String floorListingId = "";
        double topBidNative = 0.0;
        double topBidUsd = 0.0;
        String topBidId = "";
        double lastTradeNative = 0.0;
        double lastTradeUsd = 0.0;
    }

    static class AlertSignal {
        String id;
        String title;
        String body;
        int severity;

        AlertSignal(String id, String title, String body, int severity) {
            this.id = id;
            this.title = title;
            this.body = body;
            this.severity = severity;
        }
    }
}

package com.feltch.habbowatchtower;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class Store {
    private static final String PREFS = "habbo_watchtower_prefs";
    private final SharedPreferences prefs;

    Store(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    String wallet() { return prefs.getString("wallet", Models.DEFAULT_WALLET); }
    void setWallet(String wallet) { prefs.edit().putString("wallet", wallet.trim()).apply(); }

    String immutableApiKey() { return prefs.getString("immutable_api_key", ""); }
    void setImmutableApiKey(String key) { prefs.edit().putString("immutable_api_key", key.trim()).apply(); }

    int scanIntervalMinutes() { return prefs.getInt("scan_interval_minutes", 10); }
    void setScanIntervalMinutes(int minutes) { prefs.edit().putInt("scan_interval_minutes", Math.max(2, minutes)).apply(); }

    int scanBatchSize() { return prefs.getInt("scan_batch_size", 50); }
    void setScanBatchSize(int count) { prefs.edit().putInt("scan_batch_size", Math.max(1, Math.min(100, count))).apply(); }

    String itemSortMode() { return MarketSort.normalize(prefs.getString("item_sort_mode", Models.SORT_VALUE)); }
    void setItemSortMode(String mode) { prefs.edit().putString("item_sort_mode", MarketSort.normalize(mode)).apply(); }

    int salesLookbackDays() { return prefs.getInt("sales_lookback_days", 30); }
    void setSalesLookbackDays(int days) { prefs.edit().putInt("sales_lookback_days", Math.max(1, days)).apply(); }

    int minSales() { return prefs.getInt("min_sales", 2); }
    void setMinSales(int count) { prefs.edit().putInt("min_sales", Math.max(1, count)).apply(); }

    double cheapDiscount() { return Double.longBitsToDouble(prefs.getLong("cheap_discount", Double.doubleToLongBits(0.70))); }
    void setCheapDiscount(double ratio) { prefs.edit().putLong("cheap_discount", Double.doubleToLongBits(clamp(ratio, 0.10, 0.95))).apply(); }

    double sellPremium() { return Double.longBitsToDouble(prefs.getLong("sell_premium", Double.doubleToLongBits(1.20))); }
    void setSellPremium(double ratio) { prefs.edit().putLong("sell_premium", Double.doubleToLongBits(clamp(ratio, 1.01, 5.00))).apply(); }

    boolean watcherEnabled() { return prefs.getBoolean("watcher_enabled", false); }
    void setWatcherEnabled(boolean enabled) { prefs.edit().putBoolean("watcher_enabled", enabled).apply(); }

    String displayCurrency() { return normalizeCurrency(prefs.getString("display_currency", "USD")); }
    void setDisplayCurrency(String currency) { prefs.edit().putString("display_currency", normalizeCurrency(currency)).apply(); }

    boolean debugBuyNextScan() { return prefs.getBoolean("debug_buy_next_scan", false); }
    void setDebugBuyNextScan(boolean enabled) { prefs.edit().putBoolean("debug_buy_next_scan", enabled).apply(); }
    boolean consumeDebugBuyNextScan() {
        boolean enabled = debugBuyNextScan();
        if (enabled) prefs.edit().putBoolean("debug_buy_next_scan", false).apply();
        return enabled;
    }

    boolean sellAlertsEnabled(String itemKey) { return prefs.getBoolean("sell_alert_" + itemKey, true); }
    void setSellAlertsEnabled(String itemKey, boolean enabled) { prefs.edit().putBoolean("sell_alert_" + itemKey, enabled).apply(); }

    long lastAlertMillis(String signalId) { return prefs.getLong("alerted_" + signalId, 0L); }
    void markAlerted(String signalId) { prefs.edit().putLong("alerted_" + signalId, System.currentTimeMillis()).apply(); }

    String statusText() { return prefs.getString("status_text", "Not scanned yet."); }
    void setStatusText(String text) { prefs.edit().putString("status_text", text).apply(); }

    void saveItems(List<Models.NftItem> items) {
        try {
            JSONArray arr = new JSONArray();
            for (Models.NftItem item : items) {
                JSONObject o = new JSONObject();
                o.put("contractAddress", item.contractAddress);
                o.put("tokenId", item.tokenId);
                o.put("tokenIdsCsv", item.tokenIdsCsv);
                o.put("name", item.name);
                o.put("image", item.image);
                o.put("metadataId", item.metadataId);
                o.put("stackId", item.stackId);
                o.put("balance", item.balance);
                o.put("quantity", item.quantity);
                o.put("monthlySalesCount", item.monthlySalesCount);
                o.put("monthlyAverageNative", item.monthlyAverageNative);
                o.put("monthlyMedianNative", item.monthlyMedianNative);
                o.put("currentFloorNative", item.currentFloorNative);
                o.put("topBidNative", item.topBidNative);
                o.put("lastSaleNative", item.lastSaleNative);
                o.put("marketUpdatedMillis", item.marketUpdatedMillis);
                arr.put(o);
            }
            prefs.edit().putString("items_json", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    List<Models.NftItem> loadItems() {
        List<Models.NftItem> items = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("items_json", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Models.NftItem item = new Models.NftItem();
                item.contractAddress = o.optString("contractAddress", "");
                item.tokenId = o.optString("tokenId", "");
                item.tokenIdsCsv = o.optString("tokenIdsCsv", item.tokenId);
                item.name = o.optString("name", "Unknown item");
                item.image = o.optString("image", "");
                item.metadataId = o.optString("metadataId", "");
                item.stackId = o.optString("stackId", "");
                item.balance = o.optString("balance", "1");
                item.quantity = o.optInt("quantity", safeInt(item.balance, 1));
                item.monthlySalesCount = o.optInt("monthlySalesCount", 0);
                item.monthlyAverageNative = o.optDouble("monthlyAverageNative", 0.0);
                item.monthlyMedianNative = o.optDouble("monthlyMedianNative", 0.0);
                item.currentFloorNative = o.optDouble("currentFloorNative", 0.0);
                item.topBidNative = o.optDouble("topBidNative", 0.0);
                item.lastSaleNative = o.optDouble("lastSaleNative", 0.0);
                item.marketUpdatedMillis = o.optLong("marketUpdatedMillis", 0L);
                if (!item.contractAddress.isEmpty() && !item.tokenId.isEmpty()) items.add(item);
            }
        } catch (Exception ignored) { }
        return items;
    }

    Set<String> watchedContracts() {
        Set<String> set = new HashSet<>(prefs.getStringSet("watched_contracts", new HashSet<String>()));
        for (Models.NftItem item : loadItems()) set.add(item.contractAddress.toLowerCase(Locale.US));
        return set;
    }

    void addWatchedContract(String contract) {
        if (contract == null || contract.trim().isEmpty()) return;
        Set<String> set = watchedContracts();
        set.add(contract.trim().toLowerCase(Locale.US));
        prefs.edit().putStringSet("watched_contracts", set).apply();
    }

    private String normalizeCurrency(String raw) {
        String c = raw == null ? "USD" : raw.trim().toUpperCase(Locale.US);
        for (String allowed : Models.DISPLAY_CURRENCIES) if (allowed.equals(c)) return c;
        return "USD";
    }

    private static int safeInt(String raw, int fallback) {
        try { return Math.max(0, Integer.parseInt(raw == null ? "" : raw.trim())); }
        catch (Exception ignored) { return fallback; }
    }

    private double clamp(double n, double min, double max) {
        return Math.max(min, Math.min(max, n));
    }
}

package com.feltch.habbowatchtower;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Store {
    private static final String PREFS = "habbo_watchtower_prefs";
    private final SharedPreferences prefs;

    Store(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    String wallet() { return prefs.getString("wallet", Models.DEFAULT_WALLET); }
    void setWallet(String wallet) { prefs.edit().putString("wallet", wallet.trim()).apply(); }

    String immutableApiKey() { return prefs.getString("immutable_api_key", ""); }
    void setImmutableApiKey(String key) { prefs.edit().putString("immutable_api_key", key.trim()).apply(); }

    int scanIntervalMinutes() { return prefs.getInt("scan_interval_minutes", 10); }
    void setScanIntervalMinutes(int minutes) { prefs.edit().putInt("scan_interval_minutes", Math.max(2, minutes)).apply(); }

    int salesLookbackDays() { return prefs.getInt("sales_lookback_days", 30); }
    void setSalesLookbackDays(int days) { prefs.edit().putInt("sales_lookback_days", Math.max(1, days)).apply(); }

    int minSales() { return prefs.getInt("min_sales", 2); }
    void setMinSales(int count) { prefs.edit().putInt("min_sales", Math.max(1, count)).apply(); }

    double cheapDiscount() { return Double.longBitsToDouble(prefs.getLong("cheap_discount", Double.doubleToLongBits(0.70))); }
    void setCheapDiscount(double ratio) { prefs.edit().putLong("cheap_discount", Double.doubleToLongBits(clamp(ratio, 0.10, 0.95))).apply(); }

    double sellPremium() { return Double.longBitsToDouble(prefs.getLong("sell_premium", Double.doubleToLongBits(1.20))); }
    void setSellPremium(double ratio) { prefs.edit().putLong("sell_premium", Double.doubleToLongBits(clamp(ratio, 1.01, 5.00))).apply(); }

    boolean watcherEnabled() { return prefs.getBoolean("watcher_enabled", false); }
    void setWatcherEnabled(boolean enabled) { prefs.edit().putBoolean("watcher_enabled", enabled).apply(); }

    boolean sellAlertsEnabled(String itemKey) { return prefs.getBoolean("sell_alert_" + itemKey, true); }
    void setSellAlertsEnabled(String itemKey, boolean enabled) { prefs.edit().putBoolean("sell_alert_" + itemKey, enabled).apply(); }

    long lastAlertMillis(String signalId) { return prefs.getLong("alerted_" + signalId, 0L); }
    void markAlerted(String signalId) { prefs.edit().putLong("alerted_" + signalId, System.currentTimeMillis()).apply(); }

    String statusText() { return prefs.getString("status_text", "Not scanned yet."); }
    void setStatusText(String text) { prefs.edit().putString("status_text", text).apply(); }

    void saveItems(List<Models.NftItem> items) {
        try {
            JSONArray arr = new JSONArray();
            for (Models.NftItem item : items) {
                JSONObject o = new JSONObject();
                o.put("contractAddress", item.contractAddress);
                o.put("tokenId", item.tokenId);
                o.put("name", item.name);
                o.put("image", item.image);
                o.put("metadataId", item.metadataId);
                o.put("balance", item.balance);
                arr.put(o);
            }
            prefs.edit().putString("items_json", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    List<Models.NftItem> loadItems() {
        List<Models.NftItem> items = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("items_json", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Models.NftItem item = new Models.NftItem();
                item.contractAddress = o.optString("contractAddress", "");
                item.tokenId = o.optString("tokenId", "");
                item.name = o.optString("name", "Unknown item");
                item.image = o.optString("image", "");
                item.metadataId = o.optString("metadataId", "");
                item.balance = o.optString("balance", "1");
                if (!item.contractAddress.isEmpty() && !item.tokenId.isEmpty()) items.add(item);
            }
        } catch (Exception ignored) { }
        return items;
    }

    Set<String> watchedContracts() {
        Set<String> set = new HashSet<>(prefs.getStringSet("watched_contracts", new HashSet<String>()));
        for (Models.NftItem item : loadItems()) set.add(item.contractAddress.toLowerCase());
        return set;
    }

    void addWatchedContract(String contract) {
        if (contract == null || contract.trim().isEmpty()) return;
        Set<String> set = watchedContracts();
        set.add(contract.trim().toLowerCase());
        prefs.edit().putStringSet("watched_contracts", set).apply();
    }

    private double clamp(double n, double min, double max) {
        return Math.max(min, Math.min(max, n));
    }
}

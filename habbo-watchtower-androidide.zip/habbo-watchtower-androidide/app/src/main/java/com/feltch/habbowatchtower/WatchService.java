package com.feltch.habbowatchtower;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class WatchService extends Service {
    public static final String ACTION_START = "com.feltch.habbowatchtower.START";
    public static final String ACTION_STOP = "com.feltch.habbowatchtower.STOP";
    public static final String ACTION_SCAN_ONCE = "com.feltch.habbowatchtower.SCAN_ONCE";
    public static final String ACTION_REFRESH_UI = "com.feltch.habbowatchtower.REFRESH_UI";

    private static final int FOREGROUND_ID = 1001;
    private static final String WATCH_CHANNEL = "watcher";
    private static final String ALERT_CHANNEL = "alerts";
    private ScheduledExecutorService scheduler;
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private Store store;

    @Override public void onCreate() {
        super.onCreate();
        store = new Store(this);
        createChannels();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopWatcher();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FOREGROUND_ID, watcherNotification("Running", "Watching Habbo market signals."), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(FOREGROUND_ID, watcherNotification("Running", "Watching Habbo market signals."));
        }
        if (ACTION_SCAN_ONCE.equals(action)) {
            runScanAsync();
            return START_STICKY;
        }
        startWatcherLoop();
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        super.onDestroy();
    }

    private void startWatcherLoop() {
        store.setWatcherEnabled(true);
        if (scheduler != null && !scheduler.isShutdown()) return;
        scheduler = Executors.newSingleThreadScheduledExecutor();
        int interval = store.scanIntervalMinutes();
        scheduler.scheduleWithFixedDelay(this::safeScan, 2, Math.max(2, interval), TimeUnit.MINUTES);
        runScanAsync();
    }

    private void stopWatcher() {
        store.setWatcherEnabled(false);
        store.setStatusText("Watcher stopped.");
        if (scheduler != null) scheduler.shutdownNow();
        sendBroadcast(new Intent(ACTION_REFRESH_UI));
        stopForeground(true);
        stopSelf();
    }

    private void runScanAsync() {
        Executors.newSingleThreadExecutor().execute(this::safeScan);
    }

    private void safeScan() {
        if (!scanning.compareAndSet(false, true)) return;
        try {
            doScan();
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.toString() : e.getMessage();
            store.setStatusText("Scan failed: " + trim(msg, 220));
            sendBroadcast(new Intent(ACTION_REFRESH_UI));
            notifyAlert("Habbo scan failed", trim(msg, 180), 9000 + (int)(System.currentTimeMillis() % 500));
        } finally {
            scanning.set(false);
        }
    }

    private void doScan() throws Exception {
        store.setStatusText("Scanning wallet and market…");
        sendBroadcast(new Intent(ACTION_REFRESH_UI));

        ImmutableApi api = new ImmutableApi(store.immutableApiKey());
        List<Models.NftItem> items = api.listInventory(store.wallet());
        store.saveItems(items);
        for (Models.NftItem item : items) store.addWatchedContract(item.contractAddress);

        AlertEngine engine = new AlertEngine(store);
        int signals = 0;
        int checked = 0;
        int maxItems = Math.min(items.size(), 40); // Keeps phone/API load sane for v0.1.
        for (int i = 0; i < maxItems; i++) {
            Models.NftItem item = items.get(i);
            try {
                Models.PriceStats stats = api.getSalesStats(item.contractAddress, item.tokenId, store.salesLookbackDays());
                Models.PriceQuote quote = api.getQuote(item.contractAddress, item.tokenId);
                List<Models.Listing> listings = api.listActiveListingsForItem(item.contractAddress, item.tokenId);
                List<Models.AlertSignal> itemSignals = engine.evaluateItem(item, stats, quote, listings);
                for (Models.AlertSignal signal : itemSignals) {
                    if (engine.shouldNotify(signal)) {
                        notifyAlert(signal.title, signal.body, Math.abs(signal.id.hashCode()));
                        engine.markNotified(signal);
                        signals++;
                    }
                }
                checked++;
                Thread.sleep(250); // Gentle pacing to avoid bursts/rate limits.
            } catch (Exception ignored) {
                // One item failing should not kill the whole scan.
            }
        }
        String status = String.format(Locale.US, "Last scan checked %d/%d wallet items. New alerts: %d.", checked, items.size(), signals);
        store.setStatusText(status);
        updateForeground("Last scan complete", status);
        sendBroadcast(new Intent(ACTION_REFRESH_UI));
    }

    private Notification watcherNotification(String title, String body) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stopIntent = new Intent(this, WatchService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, WATCH_CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(content)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
                .build();
    }

    private void updateForeground(String title, String body) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(FOREGROUND_ID, watcherNotification(title, body));
    }

    private void notifyAlert(String title, String body, int id) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ALERT_CHANNEL) : new Notification.Builder(this);
        Notification n = b.setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .setContentIntent(content)
                .build();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(id, n);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel watcher = new NotificationChannel(WATCH_CHANNEL, "Watcher status", NotificationManager.IMPORTANCE_LOW);
        watcher.setDescription("Persistent status notification while the market watcher is running.");
        NotificationChannel alerts = new NotificationChannel(ALERT_CHANNEL, "Market alerts", NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("Cheap listings and sell signals.");
        nm.createNotificationChannel(watcher);
        nm.createNotificationChannel(alerts);
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}

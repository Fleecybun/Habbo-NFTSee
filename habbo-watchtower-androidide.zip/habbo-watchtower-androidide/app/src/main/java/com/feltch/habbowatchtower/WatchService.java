package com.feltch.habbowatchtower;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class WatchService extends Service {
    public static final String ACTION_START = "com.feltch.habbowatchtower.START";
    public static final String ACTION_STOP = "com.feltch.habbowatchtower.STOP";
    public static final String ACTION_SCAN_ONCE = "com.feltch.habbowatchtower.SCAN_ONCE";
    public static final String ACTION_REFRESH_UI = "com.feltch.habbowatchtower.REFRESH_UI";

    private static final int FOREGROUND_ID = 1001;
    private static final String WATCH_CHANNEL = "watcher";
    private static final String ALERT_CHANNEL = "alerts";
    private ScheduledExecutorService scheduler;
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private Store store;
    private WatchDatabase db;

    @Override public void onCreate() {
        super.onCreate();
        store = new Store(this);
        db = new WatchDatabase(this);
        createChannels();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            store.clearScanProgress();
            stopWatcher();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FOREGROUND_ID, watcherNotification("Running", "Watching Habbo market signals."), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(FOREGROUND_ID, watcherNotification("Running", "Watching Habbo market signals."));
        }
        if (ACTION_SCAN_ONCE.equals(action)) {
            runScanAsync();
            return START_STICKY;
        }
        startWatcherLoop();
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        super.onDestroy();
    }

    private void startWatcherLoop() {
        store.setWatcherEnabled(true);
        if (scheduler != null && !scheduler.isShutdown()) return;
        scheduler = Executors.newSingleThreadScheduledExecutor();
        int interval = store.scanIntervalMinutes();
        scheduler.scheduleWithFixedDelay(this::safeScan, 2, Math.max(2, interval), TimeUnit.MINUTES);
        runScanAsync();
    }

    private void stopWatcher() {
        store.setWatcherEnabled(false);
        store.setStatusText("Watcher stopped.");
        if (scheduler != null) scheduler.shutdownNow();
        sendBroadcast(new Intent(ACTION_REFRESH_UI));
        stopForeground(true);
        stopSelf();
    }

    private void runScanAsync() { Executors.newSingleThreadExecutor().execute(this::safeScan); }

    private void safeScan() {
        if (!scanning.compareAndSet(false, true)) return;
        try {
            doScan();
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.toString() : e.getMessage();
            store.setStatusText("Scan failed: " + trim(msg, 220));
            store.setScanProgress(false, "Scan failed", store.scanProgressDone(), store.scanProgressTotal(), "Failed: " + trim(msg, 180));
            sendBroadcast(new Intent(ACTION_REFRESH_UI));
            notifyAlert("Habbo scan failed", trim(msg, 180), 9000 + (int)(System.currentTimeMillis() % 500));
        } finally {
            scanning.set(false);
        }
    }

    private void doScan() throws Exception {
        boolean initialFullScan = !store.initialFullScanComplete();
        if (initialFullScan) {
            String notice = "Initial full wallet scan starting. This prices every grouped wallet item and pulls sale history so sorting works properly. It can take a long time — please be patient.";
            store.setStatusText(notice);
            store.setScanProgress(true, "Initial full scan", 0, 0, "Loading wallet inventory before pricing every grouped item…");
            updateForeground("Initial full scan", "Loading wallet inventory…");
        } else {
            store.setStatusText("Scanning wallet and market…");
            store.setScanProgress(true, "Watch scan", 0, 0, "Loading wallet inventory…");
        }
        sendBroadcast(new Intent(ACTION_REFRESH_UI));

        CurrencyRates.refreshIfStale(this);
        AlertEngine engine = new AlertEngine(store);
        int signals = 0;

        if (store.consumeDebugBuyNextScan()) {
            Models.AlertSignal debug = engine.debugBuySignal();
            db.recordSignal(debug, true);
            notifyAlert(debug.title, debug.body, notificationId(debug));
            engine.markNotified(debug);
            signals++;
        }

        ImmutableApi api = new ImmutableApi(store.immutableApiKey());
        List<Models.NftItem> cachedItems = store.loadItems();
        List<Models.NftItem> items = api.listInventory(store.wallet());
        mergeCachedMarketData(items, cachedItems);
        store.saveItems(items);
        for (Models.NftItem item : items) store.addWatchedContract(item.contractAddress);

        List<Models.NftItem> scanOrder = MarketSort.sortedCopy(items, store.itemSortMode());
        int checked = 0;
        int attempted = 0;
        int maxItems = initialFullScan ? scanOrder.size() : Math.min(scanOrder.size(), store.scanBatchSize());
        int statsLookbackDays = Math.max(30, store.salesLookbackDays());
        String prepProgress = initialFullScan
                ? String.format(Locale.US, "Initial full scan 0/%d grouped wallet items • %d remaining. Pulling sale history and floor data — this can take a long time.", maxItems, maxItems)
                : String.format(Locale.US, "Watch scan 0/%d items this pass • %d remaining this pass • %d total grouped wallet items. Priority: %s.", maxItems, maxItems, items.size(), store.itemSortMode());
        store.setScanProgress(true, initialFullScan ? "Initial full scan" : "Watch scan", 0, maxItems, prepProgress);
        updateForeground(initialFullScan ? "Initial full scan" : "Scan running", prepProgress);
        sendBroadcast(new Intent(ACTION_REFRESH_UI));

        for (int i = 0; i < maxItems; i++) {
            Models.NftItem item = scanOrder.get(i);
            attempted++;
            try {
                Models.PriceStats stats = api.getSalesStats(item, statsLookbackDays);
                Models.PriceQuote quote = api.getQuote(item);
                List<Models.Listing> listings = api.listActiveListingsForGroup(item);

                item.monthlySalesCount = stats.countSinceDays(30);
                item.salesCount3d = stats.countSinceDays(3);
                item.salesCount14d = stats.countSinceDays(14);
                item.salesCount30d = stats.countSinceDays(30);
                item.monthlyAverageNative = stats.averageNative;
                item.monthlyMedianNative = stats.medianNative;
                item.currentFloorNative = quote.floorNative;
                item.topBidNative = quote.topBidNative;
                item.lastSaleNative = stats.lastSaleNative > 0.0 ? stats.lastSaleNative : quote.lastTradeNative;
                item.marketUpdatedMillis = System.currentTimeMillis();

                List<Models.AlertSignal> itemSignals = engine.evaluateItem(item, stats, quote, listings);
                for (Models.AlertSignal signal : itemSignals) {
                    boolean shouldNotify = engine.shouldNotify(signal);
                    db.recordSignal(signal, shouldNotify);
                    if (shouldNotify) {
                        notifyAlert(signal.title, signal.body, notificationId(signal));
                        engine.markNotified(signal);
                        signals++;
                    }
                }
                checked++;
            } catch (Exception ignored) {
                // One item failing should not kill the whole scan.
            }

            store.saveItems(items);
            String progress;
            int remaining = Math.max(0, maxItems - attempted);
            if (initialFullScan) {
                progress = String.format(Locale.US,
                        "Initial full scan %d/%d grouped wallet items • %d remaining. Pulling sale history and floor data — this can take a long time. New alerts: %d.",
                        attempted, maxItems, remaining, signals);
            } else {
                progress = String.format(Locale.US,
                        "Watch scan %d/%d this pass • %d remaining this pass • %d total grouped wallet items. Priority: %s. New alerts: %d.",
                        attempted, maxItems, remaining, items.size(), store.itemSortMode(), signals);
            }
            store.setStatusText(progress);
            store.setScanProgress(true, initialFullScan ? "Initial full scan" : "Watch scan", attempted, maxItems, progress);
            updateForeground(initialFullScan ? "Initial full scan" : "Scan running", progress);
            sendBroadcast(new Intent(ACTION_REFRESH_UI));
            Thread.sleep(initialFullScan ? 300 : 250);
        }

        store.saveItems(items);
        if (initialFullScan && attempted >= scanOrder.size()) {
            store.markInitialFullScanCompleteForWallet(store.wallet());
        }
        String status = initialFullScan
                ? String.format(Locale.US, "Initial full scan complete: checked %d/%d grouped wallet items. Priority: %s. New alerts: %d.", checked, items.size(), store.itemSortMode(), signals)
                : String.format(Locale.US, "Last scan checked %d/%d grouped wallet items. Priority: %s. New alerts: %d.", checked, items.size(), store.itemSortMode(), signals);
        store.setStatusText(status);
        store.setScanProgress(false, initialFullScan ? "Initial full scan" : "Watch scan", maxItems, maxItems, status);
        updateForeground(initialFullScan ? "Initial full scan complete" : "Last scan complete", status);
        sendBroadcast(new Intent(ACTION_REFRESH_UI));
    }


    private void mergeCachedMarketData(List<Models.NftItem> fresh, List<Models.NftItem> cached) {
        Map<String, Models.NftItem> byKey = new HashMap<>();
        for (Models.NftItem item : cached) byKey.put(item.key(), item);
        for (Models.NftItem item : fresh) {
            Models.NftItem old = byKey.get(item.key());
            if (old == null) continue;
            item.monthlySalesCount = old.monthlySalesCount;
            item.salesCount3d = old.salesCount3d;
            item.salesCount14d = old.salesCount14d;
            item.salesCount30d = old.salesCount30d;
            item.monthlyAverageNative = old.monthlyAverageNative;
            item.monthlyMedianNative = old.monthlyMedianNative;
            item.currentFloorNative = old.currentFloorNative;
            item.topBidNative = old.topBidNative;
            item.lastSaleNative = old.lastSaleNative;
            item.marketUpdatedMillis = old.marketUpdatedMillis;
        }
    }

    private Notification watcherNotification(String title, String body) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stopIntent = new Intent(this, WatchService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, WATCH_CHANNEL) : new Notification.Builder(this);
        b.setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(content)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop);
        if (store != null && store.scanProgressActive()) {
            int total = store.scanProgressTotal();
            int done = store.scanProgressDone();
            if (total > 0) b.setProgress(total, Math.max(0, Math.min(done, total)), false);
            else b.setProgress(100, 0, true);
        } else if (store != null && store.scanProgressTotal() > 0) {
            int total = store.scanProgressTotal();
            b.setProgress(total, total, false);
        }
        return b.build();
    }

    private void updateForeground(String title, String body) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(FOREGROUND_ID, watcherNotification(title, body));
    }

    private void notifyAlert(String title, String body, int id) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ALERT_CHANNEL) : new Notification.Builder(this);
        Notification n = b.setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .setContentIntent(content)
                .build();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(id, n);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel watcher = new NotificationChannel(WATCH_CHANNEL, "Watcher status", NotificationManager.IMPORTANCE_LOW);
        watcher.setDescription("Persistent status notification while the market watcher is running.");
        NotificationChannel alerts = new NotificationChannel(ALERT_CHANNEL, "Market alerts", NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("Cheap listings and sell signals.");
        nm.createNotificationChannel(watcher);
        nm.createNotificationChannel(alerts);
    }

    private static int notificationId(Models.AlertSignal signal) {
        int h = signal == null || signal.id == null ? (int) System.currentTimeMillis() : signal.id.hashCode();
        return 20000 + Math.abs(h % 1_000_000);
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}

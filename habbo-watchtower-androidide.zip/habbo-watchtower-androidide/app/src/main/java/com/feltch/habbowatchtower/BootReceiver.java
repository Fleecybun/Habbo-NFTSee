package com.feltch.habbowatchtower;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Store store = new Store(context);
        if (!store.watcherEnabled()) return;
        Intent service = new Intent(context, WatchService.class).setAction(WatchService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
        else context.startService(service);
    }
}

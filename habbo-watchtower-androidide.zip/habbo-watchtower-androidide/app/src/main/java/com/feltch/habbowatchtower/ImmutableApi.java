package com.feltch.habbowatchtower;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class ImmutableApi {
    private final String apiKey;

    ImmutableApi(String apiKey) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
    }

    List<Models.NftItem> listInventory(String wallet) throws Exception {
        List<Models.NftItem> raw = new ArrayList<>();
        String cursor = null;
        int safety = 0;
        do {
            String url = Models.API_BASE + "/accounts/" + enc(wallet) + "/nfts?page_size=200" + (cursor == null ? "" : "&page_cursor=" + enc(cursor));
            JSONObject root = getJson(url);
            JSONArray result = root.optJSONArray("result");
            if (result != null) {
                for (int i = 0; i < result.length(); i++) {
                    JSONObject o = result.optJSONObject(i);
                    if (o == null) continue;
                    Models.NftItem item = new Models.NftItem();
                    item.contractAddress = o.optString("contract_address", "");
                    item.tokenId = o.optString("token_id", "");
                    item.tokenIdsCsv = item.tokenId;
                    item.name = o.optString("name", fallbackName(item.contractAddress, item.tokenId));
                    item.image = o.optString("image", "");
                    item.metadataId = o.optString("metadata_id", "");
                    item.stackId = o.optString("stack_id", o.optString("stackId", ""));
                    item.balance = o.optString("balance", "1");
                    item.quantity = Math.max(1, safeInt(item.balance, 1));
                    if (!item.contractAddress.isEmpty() && !item.tokenId.isEmpty()) raw.add(item);
                }
            }
            cursor = nextCursor(root);
            safety++;
        } while (cursor != null && safety < 20);
        return groupInventory(raw);
    }

    Models.PriceQuote getQuote(Models.NftItem item) throws Exception {
        return getQuote(item.contractAddress, item.tokenId);
    }

    Models.PriceQuote getQuote(String contractAddress, String tokenId) throws Exception {
        Models.PriceQuote quote = new Models.PriceQuote();
        String url = Models.API_BASE + "/quotes/" + enc(contractAddress) + "/nfts?token_id=" + enc(tokenId);
        JSONObject root = getJson(url);
        JSONArray result = root.optJSONArray("result");
        if (result == null || result.length() == 0) return quote;
        JSONObject first = result.optJSONObject(0);
        if (first == null) return quote;

        JSONObject marketStack = first.optJSONObject("market_stack");
        JSONObject marketNft = first.optJSONObject("market_nft");
        JSONObject marketCollection = first.optJSONObject("market_collection");

        JSONObject floor = firstNonNull(
                path(marketStack, "floor_listing"),
                path(marketNft, "floor_listing"),
                path(marketCollection, "floor_listing")
        );
        JSONObject topBid = firstNonNull(
                path(marketStack, "top_bid"),
                path(marketNft, "top_bid"),
                path(marketCollection, "top_bid")
        );
        JSONObject lastTrade = firstNonNull(
                path(marketStack, "last_trade"),
                path(marketNft, "last_trade"),
                path(marketCollection, "last_trade")
        );

        if (floor != null) {
            quote.floorNative = extractNativePrice(floor);
            quote.floorUsd = extractUsdPrice(floor);
            quote.floorListingId = floor.optString("listing_id", floor.optString("id", ""));
        }
        if (topBid != null) {
            quote.topBidNative = extractNativePrice(topBid);
            quote.topBidUsd = extractUsdPrice(topBid);
            quote.topBidId = topBid.optString("bid_id", topBid.optString("id", ""));
        }
        if (lastTrade != null) {
            quote.lastTradeNative = extractNativePrice(lastTrade);
            quote.lastTradeUsd = extractUsdPrice(lastTrade);
        }
        return quote;
    }

    Models.PriceStats getSalesStats(Models.NftItem item, int lookbackDays) throws Exception {
        Models.PriceStats combined = new Models.PriceStats();
        List<String> ids = item.tokenIds();
        if (ids.isEmpty()) ids.add(item.tokenId);
        int maxIds = Math.min(ids.size(), 12); // balance signal quality with phone/API load
        for (int i = 0; i < maxIds; i++) {
            try {
                combined.absorb(getSalesStats(item.contractAddress, ids.get(i), lookbackDays));
                Thread.sleep(80);
            } catch (Exception ignored) { }
        }
        combined.recompute();
        return combined;
    }

    Models.PriceStats getSalesStats(String contractAddress, String tokenId, int lookbackDays) throws Exception {
        Models.PriceStats stats = new Models.PriceStats();
        String from = Instant.now().minus(Math.max(1, lookbackDays), ChronoUnit.DAYS).toString();
        String url = Models.API_BASE + "/activities?activity_type=sale&page_size=200&contract_address=" + enc(contractAddress) + "&token_id=" + enc(tokenId);
        JSONObject root = getJson(url);
        JSONArray result = root.optJSONArray("result");
        if (result == null) return stats;
        long cutoff = Instant.parse(from).toEpochMilli();
        for (int i = 0; i < result.length(); i++) {
            JSONObject activity = result.optJSONObject(i);
            if (activity == null) continue;
            long when = parseTime(activity.optString("indexed_at", activity.optString("updated_at", "")));
            if (when > 0 && when < cutoff) continue;
            double price = extractNativePrice(activity);
            if (price > 0.0000001) {
                stats.samples.add(price);
                if (when > stats.newestSaleMillis) {
                    stats.newestSaleMillis = when;
                    stats.lastSaleNative = price;
                }
            }
        }
        stats.recompute();
        if (stats.lastSaleNative == 0.0 && stats.salesCount > 0) stats.lastSaleNative = stats.samples.get(stats.salesCount - 1);
        return stats;
    }

    List<Models.Listing> listActiveListingsForGroup(Models.NftItem item) throws Exception {
        List<Models.Listing> all = new ArrayList<>();
        List<String> ids = item.tokenIds();
        if (ids.isEmpty()) ids.add(item.tokenId);
        int maxIds = Math.min(ids.size(), 8);
        for (int i = 0; i < maxIds; i++) {
            try {
                all.addAll(listActiveListingsForItem(item.contractAddress, ids.get(i)));
                Thread.sleep(80);
            } catch (Exception ignored) { }
        }
        all.sort(Comparator.comparingDouble(l -> l.priceNative));
        return dedupeListings(all);
    }

    List<Models.Listing> listActiveListingsForItem(String contractAddress, String tokenId) throws Exception {
        List<Models.Listing> listings = new ArrayList<>();
        String url = Models.API_BASE + "/orders/listings?status=ACTIVE&page_size=20&sort_by=buy_item_amount&sort_direction=asc" +
                "&sell_item_contract_address=" + enc(contractAddress) + "&sell_item_token_id=" + enc(tokenId);
        JSONObject root = getJson(url);
        JSONArray result = root.optJSONArray("result");
        if (result == null) return listings;
        for (int i = 0; i < result.length(); i++) {
            JSONObject o = result.optJSONObject(i);
            if (o == null) continue;
            Models.Listing l = listingFromJson(o);
            if (!l.contractAddress.isEmpty() && !l.tokenId.isEmpty()) listings.add(l);
        }
        listings.sort(Comparator.comparingDouble(l -> l.priceNative));
        return listings;
    }

    Map<String, Models.NftItem> itemsByKey(List<Models.NftItem> items) {
        Map<String, Models.NftItem> map = new HashMap<>();
        for (Models.NftItem item : items) map.put(item.key(), item);
        return map;
    }

    private List<Models.NftItem> groupInventory(List<Models.NftItem> raw) {
        LinkedHashMap<String, Models.NftItem> grouped = new LinkedHashMap<>();
        for (Models.NftItem item : raw) {
            String k = groupKeyFor(item);
            Models.NftItem g = grouped.get(k);
            if (g == null) {
                g = new Models.NftItem();
                g.contractAddress = item.contractAddress;
                g.tokenId = item.tokenId;
                g.tokenIdsCsv = item.tokenId;
                g.name = item.name;
                g.image = item.image;
                g.metadataId = item.metadataId;
                g.stackId = item.stackId;
                g.quantity = Math.max(1, item.quantity);
                g.balance = String.valueOf(g.quantity);
                grouped.put(k, g);
            } else {
                g.quantity += Math.max(1, item.quantity);
                g.balance = String.valueOf(g.quantity);
                if (g.tokenIdsCsv == null || g.tokenIdsCsv.isEmpty()) g.tokenIdsCsv = item.tokenId;
                else if (!containsCsv(g.tokenIdsCsv, item.tokenId)) g.tokenIdsCsv += "," + item.tokenId;
                if ((g.image == null || g.image.isEmpty()) && item.image != null) g.image = item.image;
                if ((g.metadataId == null || g.metadataId.isEmpty()) && item.metadataId != null) g.metadataId = item.metadataId;
                if ((g.stackId == null || g.stackId.isEmpty()) && item.stackId != null) g.stackId = item.stackId;
            }
        }
        return new ArrayList<>(grouped.values());
    }

    private static String groupKeyFor(Models.NftItem item) {
        String c = item.contractAddress == null ? "" : item.contractAddress.toLowerCase(Locale.US);
        if (item.metadataId != null && !item.metadataId.trim().isEmpty()) return c + ":metadata:" + item.metadataId.trim().toLowerCase(Locale.US);
        if (item.stackId != null && !item.stackId.trim().isEmpty()) return c + ":stack:" + item.stackId.trim().toLowerCase(Locale.US);
        if (item.name != null && !item.name.trim().isEmpty() && !item.name.contains("…") && !"Unknown item".equalsIgnoreCase(item.name.trim())) {
            return c + ":name:" + item.name.trim().toLowerCase(Locale.US);
        }
        return c + ":token:" + (item.tokenId == null ? "" : item.tokenId.toLowerCase(Locale.US));
    }

    private List<Models.Listing> dedupeListings(List<Models.Listing> input) {
        LinkedHashMap<String, Models.Listing> map = new LinkedHashMap<>();
        for (Models.Listing l : input) {
            String id = l.id == null || l.id.isEmpty() ? (l.contractAddress + ":" + l.tokenId + ":" + l.priceNative) : l.id;
            if (!map.containsKey(id)) map.put(id, l);
        }
        return new ArrayList<>(map.values());
    }

    private Models.Listing listingFromJson(JSONObject o) {
        Models.Listing l = new Models.Listing();
        l.id = o.optString("id", o.optString("order_hash", ""));
        l.seller = o.optString("account_address", "");
        l.metadataId = o.optString("metadata_id", "");
        JSONArray sell = o.optJSONArray("sell");
        if (sell != null && sell.length() > 0) {
            JSONObject s = sell.optJSONObject(0);
            if (s != null) {
                l.contractAddress = s.optString("contract_address", "");
                l.tokenId = s.optString("token_id", "");
                if (l.metadataId.isEmpty()) l.metadataId = s.optString("metadata_id", "");
            }
        }
        JSONArray buy = o.optJSONArray("buy");
        if (buy != null && buy.length() > 0) {
            JSONObject b = buy.optJSONObject(0);
            if (b != null) {
                l.priceNative = weiToNative(b.optString("amount", "0"));
                l.symbol = b.optString("symbol", b.optString("type", "ETH"));
            }
        }
        l.priceUsd = extractUsdPrice(o);
        return l;
    }

    private JSONObject getJson(String urlString) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(urlString).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", "HabboWatchtowerNative/0.2");
        if (!apiKey.isEmpty()) con.setRequestProperty("x-immutable-api-key", apiKey);
        int code = con.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code < 200 || code >= 300) throw new Exception("Immutable API HTTP " + code + ": " + sb);
        return new JSONObject(sb.toString());
    }

    private static String nextCursor(JSONObject root) {
        JSONObject page = root.optJSONObject("page");
        if (page == null) return null;
        String next = page.optString("next_cursor", "");
        return next.isEmpty() || "null".equals(next) ? null : next;
    }

    static double extractNativePrice(JSONObject obj) {
        if (obj == null) return 0.0;
        JSONObject priceDetails = obj.optJSONObject("price_details");
        if (priceDetails != null) {
            double direct = priceFromPriceDetails(priceDetails);
            if (direct > 0.0) return direct;
        }
        JSONArray priceDetailsArray = obj.optJSONArray("price_details");
        if (priceDetailsArray != null) {
            for (int i = 0; i < priceDetailsArray.length(); i++) {
                double d = priceFromPriceDetails(priceDetailsArray.optJSONObject(i));
                if (d > 0.0) return d;
            }
        }
        return recursiveAmountSearch(obj, new HashSet<Integer>());
    }

    static double extractUsdPrice(JSONObject obj) {
        if (obj == null) return 0.0;
        double price = recursiveUsdSearch(obj, new HashSet<Integer>());
        return price < 0.0 ? 0.0 : price;
    }

    private static double priceFromPriceDetails(JSONObject pd) {
        if (pd == null) return 0.0;
        String amt = pd.optString("fee_inclusive_amount", pd.optString("amount", ""));
        double nativePrice = weiToNative(amt);
        return nativePrice > 0.0 ? nativePrice : safeDouble(amt);
    }

    private static double recursiveUsdSearch(Object node, Set<Integer> seen) {
        if (node == null) return -1.0;
        int id = System.identityHashCode(node);
        if (seen.contains(id)) return -1.0;
        seen.add(id);
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject converted = o.optJSONObject("converted_prices");
            if (converted != null) {
                double usd = safeDouble(converted.optString("USD", converted.optString("usd", "")));
                if (usd > 0.0) return usd;
            }
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String key = names.optString(i);
                    double child = recursiveUsdSearch(o.opt(key), seen);
                    if (child > 0.0) return child;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                double child = recursiveUsdSearch(a.opt(i), seen);
                if (child > 0.0) return child;
            }
        }
        return -1.0;
    }

    private static double recursiveAmountSearch(Object node, Set<Integer> seen) {
        if (node == null) return 0.0;
        int id = System.identityHashCode(node);
        if (seen.contains(id)) return 0.0;
        seen.add(id);
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject pd = o.optJSONObject("price_details");
            double fromPd = priceFromPriceDetails(pd);
            if (fromPd > 0.0) return fromPd;
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String key = names.optString(i).toLowerCase(Locale.US);
                    Object value = o.opt(names.optString(i));
                    if ((key.equals("amount") || key.endsWith("_amount") || key.equals("fee_inclusive_amount")) && value instanceof String) {
                        double p = weiToNative((String) value);
                        if (p > 0.0000001 && p < 1_000_000.0) return p;
                    }
                    double child = recursiveAmountSearch(value, seen);
                    if (child > 0.0) return child;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                double child = recursiveAmountSearch(a.opt(i), seen);
                if (child > 0.0) return child;
            }
        }
        return 0.0;
    }

    static double weiToNative(String amount) {
        try {
            if (amount == null || amount.trim().isEmpty()) return 0.0;
            BigDecimal wei = new BigDecimal(amount.trim());
            if (wei.compareTo(BigDecimal.ZERO) <= 0) return 0.0;
            if (amount.contains(".")) return wei.doubleValue();
            return wei.movePointLeft(18).doubleValue();
        } catch (Exception ignored) { return 0.0; }
    }

    private static long parseTime(String iso) {
        try { return Instant.parse(iso).toEpochMilli(); }
        catch (Exception ignored) { return 0L; }
    }

    private static double safeDouble(String raw) {
        try { return raw == null || raw.trim().isEmpty() ? 0.0 : Double.parseDouble(raw.trim()); }
        catch (Exception ignored) { return 0.0; }
    }

    private static int safeInt(String raw, int fallback) {
        try { return Integer.parseInt(raw == null ? "" : raw.trim()); }
        catch (Exception ignored) { return fallback; }
    }

    private static boolean containsCsv(String csv, String value) {
        if (csv == null || value == null) return false;
        String[] parts = csv.split(",");
        for (String p : parts) if (value.equals(p.trim())) return true;
        return false;
    }

    private static JSONObject firstNonNull(JSONObject... objs) {
        for (JSONObject obj : objs) if (obj != null) return obj;
        return null;
    }

    private static JSONObject path(JSONObject root, String key) { return root == null ? null : root.optJSONObject(key); }

    private static String enc(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, "UTF-8");
    }

    private static String fallbackName(String contract, String token) {
        String shortContract = contract == null || contract.length() < 10 ? "item" : contract.substring(0, 6) + "…" + contract.substring(contract.length() - 4);
        return shortContract + " #" + token;
    }
}

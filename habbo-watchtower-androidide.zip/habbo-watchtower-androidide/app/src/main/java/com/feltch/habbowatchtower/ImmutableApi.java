package com.feltch.habbowatchtower;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class ImmutableApi {
    private final String apiKey;

    ImmutableApi(String apiKey) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
    }

    List<Models.NftItem> listInventory(String wallet) throws Exception {
        List<Models.NftItem> out = new ArrayList<>();
        String cursor = null;
        int safety = 0;
        do {
            String url = Models.API_BASE + "/accounts/" + enc(wallet) + "/nfts?page_size=200" + (cursor == null ? "" : "&page_cursor=" + enc(cursor));
            JSONObject root = getJson(url);
            JSONArray result = root.optJSONArray("result");
            if (result != null) {
                for (int i = 0; i < result.length(); i++) {
                    JSONObject o = result.optJSONObject(i);
                    if (o == null) continue;
                    Models.NftItem item = new Models.NftItem();
                    item.contractAddress = o.optString("contract_address", "");
                    item.tokenId = o.optString("token_id", "");
                    item.name = o.optString("name", fallbackName(item.contractAddress, item.tokenId));
                    item.image = o.optString("image", "");
                    item.metadataId = o.optString("metadata_id", "");
                    item.balance = o.optString("balance", "1");
                    if (!item.contractAddress.isEmpty() && !item.tokenId.isEmpty()) out.add(item);
                }
            }
            cursor = nextCursor(root);
            safety++;
        } while (cursor != null && safety < 20);
        return out;
    }

    Models.PriceQuote getQuote(String contractAddress, String tokenId) throws Exception {
        Models.PriceQuote quote = new Models.PriceQuote();
        String url = Models.API_BASE + "/quotes/" + enc(contractAddress) + "/nfts?token_id=" + enc(tokenId) + "&payment_token=NATIVE";
        JSONObject root = getJson(url);
        JSONArray result = root.optJSONArray("result");
        if (result == null || result.length() == 0) return quote;
        JSONObject first = result.optJSONObject(0);
        if (first == null) return quote;

        JSONObject marketStack = first.optJSONObject("market_stack");
        JSONObject marketNft = first.optJSONObject("market_nft");
        JSONObject marketCollection = first.optJSONObject("market_collection");

        JSONObject floor = firstNonNull(
                path(marketStack, "floor_listing"),
                path(marketNft, "floor_listing"),
                path(marketCollection, "floor_listing")
        );
        JSONObject topBid = firstNonNull(
                path(marketNft, "top_bid"),
                path(marketStack, "top_bid"),
                path(marketCollection, "top_bid")
        );
        JSONObject lastTrade = firstNonNull(
                path(marketNft, "last_trade"),
                path(marketStack, "last_trade"),
                path(marketCollection, "last_trade")
        );

        if (floor != null) {
            quote.floorNative = extractNativePrice(floor);
            quote.floorUsd = extractUsdPrice(floor);
            quote.floorListingId = floor.optString("listing_id", "");
        }
        if (topBid != null) {
            quote.topBidNative = extractNativePrice(topBid);
            quote.topBidUsd = extractUsdPrice(topBid);
            quote.topBidId = topBid.optString("bid_id", "");
        }
        if (lastTrade != null) {
            quote.lastTradeNative = extractNativePrice(lastTrade);
            quote.lastTradeUsd = extractUsdPrice(lastTrade);
        }
        return quote;
    }

    Models.PriceStats getSalesStats(String contractAddress, String tokenId, int lookbackDays) throws Exception {
        Models.PriceStats stats = new Models.PriceStats();
        String from = Instant.now().minus(Math.max(1, lookbackDays), ChronoUnit.DAYS).toString();
        String url = Models.API_BASE + "/activities?activity_type=sale&page_size=200&contract_address=" + enc(contractAddress) + "&token_id=" + enc(tokenId);
        // The List Activities endpoint supports token_id filtering; from_updated_at is intentionally not used here
        // because some API versions expose it on activity-history only. We trim stale samples locally.
        JSONObject root = getJson(url);
        JSONArray result = root.optJSONArray("result");
        if (result == null) return stats;
        long cutoff = Instant.parse(from).toEpochMilli();
        for (int i = 0; i < result.length(); i++) {
            JSONObject activity = result.optJSONObject(i);
            if (activity == null) continue;
            long when = parseTime(activity.optString("indexed_at", activity.optString("updated_at", "")));
            if (when > 0 && when < cutoff) continue;
            double price = extractNativePrice(activity);
            if (price > 0.0) {
                stats.samples.add(price);
                if (when > stats.newestSaleMillis) {
                    stats.newestSaleMillis = when;
                    stats.lastSaleNative = price;
                }
            }
        }
        Collections.sort(stats.samples);
        stats.salesCount = stats.samples.size();
        if (stats.salesCount > 0) {
            double sum = 0.0;
            for (double p : stats.samples) sum += p;
            stats.averageNative = sum / stats.salesCount;
            int mid = stats.salesCount / 2;
            if (stats.salesCount % 2 == 0) stats.medianNative = (stats.samples.get(mid - 1) + stats.samples.get(mid)) / 2.0;
            else stats.medianNative = stats.samples.get(mid);
            if (stats.lastSaleNative == 0.0) stats.lastSaleNative = stats.samples.get(stats.salesCount - 1);
        }
        return stats;
    }

    List<Models.Listing> listActiveListingsForItem(String contractAddress, String tokenId) throws Exception {
        List<Models.Listing> listings = new ArrayList<>();
        String url = Models.API_BASE + "/orders/listings?status=ACTIVE&page_size=20&sort_by=buy_item_amount&sort_direction=asc" +
                "&sell_item_contract_address=" + enc(contractAddress) + "&sell_item_token_id=" + enc(tokenId);
        JSONObject root = getJson(url);
        JSONArray result = root.optJSONArray("result");
        if (result == null) return listings;
        for (int i = 0; i < result.length(); i++) {
            JSONObject o = result.optJSONObject(i);
            if (o == null) continue;
            Models.Listing l = listingFromJson(o);
            if (!l.contractAddress.isEmpty() && !l.tokenId.isEmpty()) listings.add(l);
        }
        listings.sort(Comparator.comparingDouble(l -> l.priceNative));
        return listings;
    }

    Map<String, Models.NftItem> itemsByKey(List<Models.NftItem> items) {
        Map<String, Models.NftItem> map = new HashMap<>();
        for (Models.NftItem item : items) map.put(item.key(), item);
        return map;
    }

    private Models.Listing listingFromJson(JSONObject o) {
        Models.Listing l = new Models.Listing();
        l.id = o.optString("id", o.optString("order_hash", ""));
        l.seller = o.optString("account_address", "");
        JSONArray sell = o.optJSONArray("sell");
        if (sell != null && sell.length() > 0) {
            JSONObject s = sell.optJSONObject(0);
            if (s != null) {
                l.contractAddress = s.optString("contract_address", "");
                l.tokenId = s.optString("token_id", "");
            }
        }
        JSONArray buy = o.optJSONArray("buy");
        if (buy != null && buy.length() > 0) {
            JSONObject b = buy.optJSONObject(0);
            if (b != null) {
                l.priceNative = weiToNative(b.optString("amount", "0"));
                l.symbol = b.optString("symbol", b.optString("type", "IMX"));
            }
        }
        l.priceUsd = extractUsdPrice(o);
        return l;
    }

    private JSONObject getJson(String urlString) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(urlString).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", "HabboWatchtowerNative/0.1");
        if (!apiKey.isEmpty()) con.setRequestProperty("x-immutable-api-key", apiKey);
        int code = con.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code < 200 || code >= 300) throw new Exception("Immutable API HTTP " + code + ": " + sb);
        return new JSONObject(sb.toString());
    }

    private static String nextCursor(JSONObject root) {
        JSONObject page = root.optJSONObject("page");
        if (page == null) return null;
        String next = page.optString("next_cursor", "");
        return next.isEmpty() || "null".equals(next) ? null : next;
    }

    static double extractNativePrice(JSONObject obj) {
        if (obj == null) return 0.0;
        // Preferred shapes from pricing endpoints.
        JSONObject priceDetails = obj.optJSONObject("price_details");
        if (priceDetails != null) {
            double direct = priceFromPriceDetails(priceDetails);
            if (direct > 0.0) return direct;
        }
        JSONArray priceDetailsArray = obj.optJSONArray("price_details");
        if (priceDetailsArray != null) {
            for (int i = 0; i < priceDetailsArray.length(); i++) {
                double d = priceFromPriceDetails(priceDetailsArray.optJSONObject(i));
                if (d > 0.0) return d;
            }
        }
        // Activity sale objects vary. Recursively search for a native-looking amount.
        return recursiveAmountSearch(obj, new HashSet<Integer>());
    }

    static double extractUsdPrice(JSONObject obj) {
        if (obj == null) return 0.0;
        double price = recursiveUsdSearch(obj, new HashSet<Integer>());
        return price < 0.0 ? 0.0 : price;
    }

    private static double priceFromPriceDetails(JSONObject pd) {
        if (pd == null) return 0.0;
        String amt = pd.optString("fee_inclusive_amount", pd.optString("amount", ""));
        double nativePrice = weiToNative(amt);
        return nativePrice > 0.0 ? nativePrice : safeDouble(amt);
    }

    private static double recursiveUsdSearch(Object node, Set<Integer> seen) {
        if (node == null) return -1.0;
        int id = System.identityHashCode(node);
        if (seen.contains(id)) return -1.0;
        seen.add(id);
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject converted = o.optJSONObject("converted_prices");
            if (converted != null) {
                double usd = safeDouble(converted.optString("USD", ""));
                if (usd > 0.0) return usd;
            }
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String key = names.optString(i);
                    double child = recursiveUsdSearch(o.opt(key), seen);
                    if (child > 0.0) return child;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                double child = recursiveUsdSearch(a.opt(i), seen);
                if (child > 0.0) return child;
            }
        }
        return -1.0;
    }

    private static double recursiveAmountSearch(Object node, Set<Integer> seen) {
        if (node == null) return 0.0;
        int id = System.identityHashCode(node);
        if (seen.contains(id)) return 0.0;
        seen.add(id);
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject pd = o.optJSONObject("price_details");
            double fromPd = priceFromPriceDetails(pd);
            if (fromPd > 0.0) return fromPd;

            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String key = names.optString(i).toLowerCase(Locale.US);
                    Object value = o.opt(names.optString(i));
                    if ((key.equals("amount") || key.endsWith("_amount") || key.equals("fee_inclusive_amount")) && value instanceof String) {
                        double p = weiToNative((String) value);
                        if (p > 0.0 && p < 1_000_000.0) return p;
                    }
                    double child = recursiveAmountSearch(value, seen);
                    if (child > 0.0) return child;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                double child = recursiveAmountSearch(a.opt(i), seen);
                if (child > 0.0) return child;
            }
        }
        return 0.0;
    }

    static double weiToNative(String amount) {
        try {
            if (amount == null || amount.trim().isEmpty()) return 0.0;
            BigDecimal wei = new BigDecimal(amount.trim());
            if (wei.compareTo(BigDecimal.ZERO) <= 0) return 0.0;
            // Immutable zkEVM native token uses 18 decimals. If a human-sized decimal is returned, keep it.
            if (amount.contains(".")) return wei.doubleValue();
            return wei.movePointLeft(18).doubleValue();
        } catch (Exception ignored) {
            return 0.0;
        }
    }

    private static long parseTime(String iso) {
        try { return Instant.parse(iso).toEpochMilli(); }
        catch (Exception ignored) { return 0L; }
    }

    private static double safeDouble(String raw) {
        try { return raw == null || raw.trim().isEmpty() ? 0.0 : Double.parseDouble(raw.trim()); }
        catch (Exception ignored) { return 0.0; }
    }

    private static JSONObject firstNonNull(JSONObject... objs) {
        for (JSONObject obj : objs) if (obj != null) return obj;
        return null;
    }

    private static JSONObject path(JSONObject root, String key) {
        return root == null ? null : root.optJSONObject(key);
    }

    private static String enc(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, "UTF-8");
    }

    private static String fallbackName(String contract, String token) {
        String shortContract = contract == null || contract.length() < 10 ? "item" : contract.substring(0, 6) + "…" + contract.substring(contract.length() - 4);
        return shortContract + " #" + token;
    }
}

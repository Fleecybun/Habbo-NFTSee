# Habbo Watchtower 0.4.0

Changes in this build:

- First scan now performs a full wallet market scan, ignoring the normal per-scan item cap.
- The UI warns that the first scan can take a long time and asks the user to confirm before starting it.
- First scan progress is shown in-app and in the persistent watcher notification.
- Regular scans still use the configurable item cap, default 50 and capped at 100.
- Added fluidity sale-count sorting windows: 3 days, 2 weeks, and 1 month.
- Wallet rows now show 3d / 2w / 1m fluidity counts.
- Debug buy alert button is moved near the top of Settings and the Settings dialog is now scrollable, so the button should be visible on phone screens.
- Changing the tracked wallet resets the initial full-scan flag for the new wallet.

Still read-only: no wallet connection, no keys, no signing, no transfers, and no write transactions.

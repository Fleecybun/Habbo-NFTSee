# Version 0.3 notes

This version keeps the read-only security model and adds configurable wallet scanning.

## Added

- Settings field: Items checked per scan, default 50 and max 100.
- Settings spinner: Sort / scan priority.
- Wallet display uses the selected sort mode.
- Scanner checks items in the same selected priority order.
- Cached market data is preserved after inventory refresh, so items not included in the current scan do not lose their prior monthly average/floor/top-bid values.
- Item rows now show estimated total value and movement percentage.

## Sort formulas

- Value: `quantity × best available unit price`, where the best price falls back in this order: current floor, top bid, monthly median, monthly average, last sale.
- Top movers: absolute percentage change between current floor/last sale and monthly median.
- Discounts: negative movement only, largest discount first.
- Most liquid: monthly sales count descending.
- Slow movers: monthly sales count ascending, then oldest checked.
- Unpriced first: never-priced items first.
- Oldest checked: oldest market data first.

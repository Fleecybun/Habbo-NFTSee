# Build Habbo Watchtower directly on Android with AndroidIDE

This version is adjusted for easier on-device builds:

- Android Gradle Plugin: 7.4.2
- compileSdk: 33
- targetSdk: 33
- Java source only, no Kotlin plugin, no native NDK
- No wallet signing, no private key, no contract writes

## Steps

1. Install AndroidIDE from a trusted source: the AndroidIDE website, GitHub Releases, or F-Droid.
2. Open AndroidIDE and finish its setup.
3. When setup asks for build tools, use the default / automated setup. It should install JDK 17 and Android SDK tools.
4. Unzip this project somewhere AndroidIDE can access, such as `Download/habbo-watchtower-androidide`.
5. Open AndroidIDE → Open Project → select the unzipped `habbo-watchtower-androidide` folder.
6. Let Gradle sync finish.
7. Use the build button, or open AndroidIDE terminal in the project folder and run:

```bash
gradle :app:assembleDebug
```

8. The APK should appear at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

9. Tap the APK to install it. Android may ask you to allow installing unknown apps from AndroidIDE or Files.

## If build fails

Try these in order:

1. Reopen AndroidIDE after setup completes.
2. Confirm the project folder is fully extracted, not opened from inside the zip.
3. Make sure you have at least 4 GB free storage and 2 GB free RAM.
4. In AndroidIDE terminal, run:

```bash
gradle --stop
gradle :app:assembleDebug --stacktrace
```

5. If it says Android SDK 33 is missing, run AndroidIDE's setup/tools installer again and install SDK 33.

## Security reminder

This app only uses your public wallet address. Do not add a seed phrase, private key, or signing wallet to this project.

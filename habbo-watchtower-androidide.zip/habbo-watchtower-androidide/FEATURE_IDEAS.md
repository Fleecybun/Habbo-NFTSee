# Feature ideas

## Useful immediately

- Alert confidence score
- Quiet hours
- Ignore list for items you never want to hear about
- Per-item thresholds instead of global thresholds
- Big red `read-only mode` indicator
- Manual refresh for one item
- Alert history screen

## Better market intelligence

- Stack-aware pricing with metadata stack endpoints
- Compare exact token vs stack vs collection floor
- Sale velocity: sales per day/week
- Spread: floor vs top bid
- Volatility filter to avoid fake bargains
- Outlier-resistant median using trimmed samples
- Price trend: 7d median vs 30d median
- Bid spike detection
- New floor undercut detection

## Android quality of life

- Battery optimization checklist
- Quiet notification channels
- Notification action buttons: mute item, open listing, scan now
- Lock-screen safe alert wording
- Watcher health heartbeat

## Later, only if desired

- TokenTrove deep links
- Discord or Telegram mirror
- Cloud backup of settings
- Multiple wallets
- Play Store-ready signed release

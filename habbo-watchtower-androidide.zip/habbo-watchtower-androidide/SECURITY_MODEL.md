# Security model

This app is intentionally read-only.

It stores:

- public wallet address
- optional Immutable API key / publishable key
- alert thresholds
- cached inventory metadata
- per-item alert toggles
- alert cooldown timestamps
- cached ETH/fiat conversion rates
- on-device SQLite alert history

It does not store:

- seed phrase
- private key
- wallet signature
- session token for a wallet
- exchange API key

It does not perform:

- wallet connection
- contract write calls
- listing creation
- bids
- swaps
- transfers
- approvals

Network requests are HTTPS requests to Immutable's API base:

`https://api.immutable.com/v1/chains/imtbl-zkevm-mainnet`

If a future version adds buying/selling, keep it as a separate app or build flavor so this watcher remains safe.
